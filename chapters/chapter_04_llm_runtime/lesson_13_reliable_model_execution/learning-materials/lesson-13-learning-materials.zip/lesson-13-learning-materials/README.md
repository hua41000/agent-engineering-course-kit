# 第 13 课学习资料

《企业级Agent工程架构实战营》｜建立高并发下可靠的模型执行机制

## 阅读

1. [PRD.md](PRD.md)：本次交付范围、业务规则、AC-991-01–19 和管理员课堂演示。
2. [TECH_DESIGN.md](TECH_DESIGN.md)：与 HTML 同源的图表、完整类型及核心代码示意；Mermaid 图需支持它的 Markdown 阅读器。
3. [TECH_DESIGN.html](TECH_DESIGN.html)：双击离线阅读，支持顶部导航、搜索、图表缩放/导出和代码复制/展开；无需启动服务或安装依赖。

## 来源与维护

工程为 Compass，Feature 991。本包是工程有效需求和设计的分发整理副本；工程需求及 AC 的维护位置为 learner-kit/code/compass/mai-specs/991-lesson-13-reliable-model-execution/design/TECH_DESIGN.md，图表阅读源为其 design/document/，核心代码示意为 design/CODE_DESIGN.md。PRD.md 在分发时整合，工程继续使用原有维护源。

对应课程代码节点为 compass/L13-complete。包内代码标记为设计示意，运行和修改应使用节点提交中的真实工程源码。

本次已完成本机 PostgreSQL 17、BFF/Agent、浏览器和并发验收；未执行 Docker 容器运行及真实厂商故障测试。课程内容页大纲仍待人工批准；代码节点不改变教学审批或正式发布状态。
