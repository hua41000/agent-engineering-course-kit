# 技术方案｜模型调用可观测与运营治理

《企业级Agent工程架构实战营》｜正式课第 14 课

先读 [PRD](PRD.md) 核对范围与验收条件。交互图和代码可在 [离线阅读版](TECH_DESIGN.html) 中查看。

## 1. 方案概述

### 1.1 最小方案与量化设计目标

在现有 Agent 路由、ModelService、ReliableExecutor 与 Adapter 中接入显式观测句柄；进程内 OTel SDK 通过 HTTP/protobuf 直接导出到 Docker Langfuse。Compass 增加关联信息、平台状态小节和一个固定只读对比表；Trace 树与趋势图复用 Langfuse。对比数据从 Langfuse 的公开聚合 API 取得，不保存新统计库。不创建通用控制面、观测数据库或账本。

| 核心问题             | 实现目标                               | 量化指标（设计目标）                                                       |
| -------------------- | -------------------------------------- | -------------------------------------------------------------------------- |
| 一轮多阶段调用难关联 | 请求根 → 分类/主模型逻辑阶段 → Attempt | 每轮 1 个请求根；实际尝试与 Attempt 观测一一对应                           |
| 慢与故障难定位       | 排队、路由、尝试、首字、收尾与状态     | 单调时钟计算；非流式 TTFT 为空；重复用量计数为 0                           |
| 后端异常影响调用     | 后台有界导出，失败降级                 | 每进程队列 512 span；每批 64；每 1 秒导出；网络预算 2 秒                   |
| 正文泄露             | 在采集入口构造安全字段                 | 属性最多 64 项、每字符串 256 字符、span events 最多 16；关闭正文采集时正文哨兵出现数为 0 |
| 统计失真             | 区分请求、逻辑阶段与尝试，标记未知     | 本机采样率 1；只在 Attempt 写原生 usage/cost；未知不填 0                   |
| 本地复现             | 独立 Langfuse Compose 栈               | UI 127.0.0.1:8104；6 个服务；停止保留全部卷                                |

512/64/1 秒/2 秒等为本期可逆设计默认值，非生产容量或 SLA。沿用模型 8/32、180 秒与原取消预算；观测不重设执行参数。

### 1.2 整体架构

```mermaid
flowchart TB
    UI[Chat / 平台能力测试] --> BFF[Web BFF 原鉴权与协议校验]
    BFF --> API[Agent HTTP：根观测与响应头]
    API --> ROUTE[RoutingService：分类与选模]
    ROUTE --> MS[ModelService：逻辑阶段与最终收尾]
    MS --> EX[ReliableExecutor：排队 / 退避 / Attempt]
    EX --> RT[单次 Runtime：Adapter / 校验 / 清理]
    RT --> LL[LiteLLM Core / SystemOne]
    API -.-> SAFE[安全元信息与显式 Observation 句柄]
    ROUTE -.-> SAFE
    MS -.-> SAFE
    EX -.-> SAFE
    RT -.-> SAFE
    SAFE --> SDK[独立 OTel TracerProvider + BatchSpanProcessor]
    SDK --> OTLP[OTLP HTTP/protobuf 有界导出]
    OTLP --> LF[Langfuse Web / Worker]
    LF --> STORAGE[独立 PostgreSQL / ClickHouse / Redis / MinIO]
    BFF --> ADMIN[管理员小节：状态与 Langfuse 入口]
    ADMIN -.独立登录.-> LF
```

| 位置                        | 本期处理                                                                 | 保持的所有权                                 |
| --------------------------- | ------------------------------------------------------------------------ | -------------------------------------------- |
| Web                         | 透传校验后的观测响应头；显示编号；平台管理状态、固定只读对比表与后台链接 | 账户、授权、UI 和 BFF                        |
| Agent HTTP / RoutingService | 请求根、分类/路由与整轮状态                                              | 父期限、分类兜底与主模型选择                 |
| ModelService                | 从 prepare 之前开始逻辑 span，finish 之后结束                            | 配置快照、解密、调用元记录和最终终态         |
| ReliableExecutor / Runtime  | 实际 Attempt、队列/退避、首片段、发送/清理结果                           | 重试与资源占用，不接受观测控制               |
| LiteLLM Adapter             | 复用回调取得安全回执；规范化响应为稳定补充                               | 协议、SDK 用量；本期不启用自动 Langfuse 集成 |
| OTel / Langfuse             | 安全 span 的异步导出、存储和可视化                                       | 第三方观测数据；不承担业务执行与计费         |

### 1.3 关键决策与减法

| 决策                                    | 选择理由                                                             | 代价与更简单备选                                         | 边界 / 演进                                  |
| --------------------------------------- | -------------------------------------------------------------------- | -------------------------------------------------------- | -------------------------------------------- |
| 用户确定 Docker Langfuse                | 直接满足 Trace 与模型比较                                            | 平台需 Web/Worker、三类存储和缓存，不能简化成单容器      | 无 HA 承诺；6 服务可按需停机                 |
| OTel 原生 span + 少量 Langfuse 属性映射 | 保留通用调用语义与字段采集控制                                       | 比自动 SDK 多一处映射；SDK 自动采集全文需额外清洗        | 映射只在 exporter 边界维护                   |
| 显式句柄传递                            | 取消/后台任务可正确结束，避免 ContextVar 跨任务回调串线              | 少量内部可选参数；无需重写 `ExecutionRequest` 或运行结果 | 每次请求独立根，无全局“当前 span”            |
| 不持久化 trace_id                       | 当轮排障通过响应头获得；旧记录可按 call_id 在 Langfuse metadata 检索 | 刷新后可能仅有 call_id；避免为关联字段迁移业务库         | 需要持久查询关联时再登记 Agent/main 迁移     |
| HTTP 响应头关联                         | start 之前即可获得 ID；取消也可保留                                  | BFF 与 Hook 需同步支持，无新增 SSE 类型                  | 不把后端地址传给租户浏览器                   |
| 指标先复用 Langfuse 观测聚合            | 完成模型比较，不增加第二套时序库                                     | 成功率分母需固定保存查询口径；采样后非完整账             | 原生 OTLP Metrics 不发往 Langfuse Trace 端点 |
| BSP 原生队列和本地自诊断 Metrics        | 复用有界后台线程，不自写重试队列                                     | 固定 SDK 版本并验证内部指标命名                          | 不读 `_queue` 等私有属性                     |
| 仅 Attempt 为 generation                | 模型用量和价格只统计一次                                             | 父级需 metadata 字段说明累计已知/未知                    | 不用父 generation 再填总 Token               |

## 2. 详细设计

### 2.1 观测对象、父子关系与状态

```mermaid
flowchart TD
    R[compass.request：一次 Chat 根] --> C1[compass.logical：intent_jev]
    R --> C2[compass.logical：intent_flash 按需]
    R --> D[compass.route：字典与选模]
    R --> M[compass.logical：inference]
    C1 --> A1[compass.attempt：generation / 一次]
    C2 --> A2[compass.attempt：generation / 一次]
    M --> Q[compass.wait：排队]
    M --> A3[compass.attempt：generation / 第一次]
    M --> B[compass.backoff：按原规则]
    M --> A4[compass.attempt：generation / 第二次按需]
    M --> F[compass.finalize：元记录收尾]
```

Provider 测试根下直接建立一个 test Logical Call；决策适配采用同样 Attempt 外壳。可靠性演示受控场景标为 `environment=showcase` / `simulation=true`，不能混入 local 的真实模型比较。

- `request.call_id` 是 Chat 用户本轮 UUID；分类现有 `uuid5(parent_call_id, role)` 与主模型 `call_id` 均保留。不得为遥测改写业务 ID。
- `trace_id` / `span_id` 由 SDK 随机生成；父上下文由句柄内部持有。外部调用新建根；已鉴权内部请求可从 `traceparent` / `tracestate` 提取远程父。Web BFF 不透传浏览器上下文，Provider 出站不注入，baggage 不传播。
- 根覆盖 Agent 接纳请求到路由/调用结果完成，包括原数据库收尾；不包含浏览器渲染与 BFF 读 EOF。已发 final 后断流的客户端协议异常仍由 BFF/浏览器处理，不回写成 Agent 的生成失败。
- Logical Call 在 `ModelService.prepare` 之前建立，已选 Provider UUID 和内部模型标识先绑定到句柄，prepare 成功后再补版本快照；准备失败、过载、超时可为零 Attempt。prepare 与 run 通过同一作用域包装，不能只在 `run` 里创建而漏准备失败。
- Attempt 在取槽成功、期限再检查后，调用 Runtime 前建立；每次 Attempt 都有新 span。取消与 RuntimeCancelled 保留原结果；清理结果登记后再结束 Attempt。
- `completed` 要求原输出校验与 `_finish` 成功；Attempt 成功但 `record_write_failed` 时，Attempt 可成功，Logical Call 与根失败；逻辑句柄将 record_write_failed 提升到根，外围取消只能补缺，不能覆盖该权威失败。
- 对取消、过载、未完成、业务拒绝等保留 `compass.status` 和安全错误码；失败、incomplete 映射 OTel ERROR / Langfuse ERROR，canceled 映射 WARNING。成功根下允许存在失败 Attempt。
- 所有正常返回、ModelError、CancelledError 都在 finally 结束对应 span 一次。进程崩溃可能只导出已结束子 span，不承诺补齐根或重放。

### 2.2 字段与隐私

只向 Observer 传结构化安全值；不把完整 `ExecutionRequest`、DTO、异常对象或 LiteLLM kwargs 交给 exporter。`ExecutionRequest`、`RuntimeResult` 与模型数据库结构保持不变，内部新增可选 `observation` 参数。

| 字段组 | 允许内容                                                                           | 限制                                                                    |
| ------ | ---------------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| 关联   | call_id、parent_call_id、attempt_id、trace/span ID                                 | UUID / SDK ID；不直接携带外部入参字符串                                 |
| 上下文 | 可信 tenant/workspace UUID、actor UUID、purpose、stage                             | 仅既有已鉴权上下文；不存名字/邮箱/Session token；平台项目仅管理员可访问 |
| 路由   | category_id、scene_id、difficulty、路由模式、固定 reason、字典/策略版本            | 只允许字典/枚举登记值，绝不放原问题或分类模型输出全文                   |
| 模型   | Provider UUID、adapter、SDK vendor、配置与绑定版本、请求/响应模型标识              | 模型标识取内部配置受限字段；不放 alias、Base URL 或连接参数             |
| 状态   | completed/failed/canceled/incomplete、安全错误码、sent、unknown、cleanup_confirmed | 错误只写固定码；不调用 `record_exception`，不写栈与 `str(exc)`          |
| 性能   | 阶段/排队/退避/尝试/收尾 ms、first_visible_ms、streamed                            | 非负有界数值；monotonic 差值计算                                        |
| 用量   | input/output/reasoning、完整性、估价状态与已知 USD 部分                            | reasoning 是 output 子集，不再相加                                      |

最大 64 个属性、每字符串 256 字符、16 个安全事件、0 个 links；超限安全字段丢弃并增加本地计数。Span 的名称固定，不含用户内容。白名单构造为主要边界，出口再校验正文策略，并拒绝 exception 与未登记的属性。`Resource` 只手工设置 service.name/version、environment，禁用自动 Resource 探测，避免环境变量与主机标识隐式采集。

启用观测后，`local` 环境在正文开关未配置时默认采集，初始化命令也会为本地 Agent 写入开启配置。其他环境默认关闭，可由部署显式覆盖。课堂哨兵与白名单验收显式设置 `COMPASS_OBSERVABILITY_CAPTURE_CONTENT=false`。开启时，仅在已采样的 Attempt 写入受限的输入和输出，包含选取的消息、结构化输入、工具字段及可见结果。默认每侧 16 KiB，超长内容保留预览和截断标记。程序过滤已知凭据和私有字段，仍可能保留业务正文。带真实业务数据的环境使用关闭配置。

业务键在采集内部保留 `compass.*` 命名，出口单一映射层将登记字段转换为 `langfuse.observation.metadata.<字段名>`，例如 `model`、`stage`、`status`、`call_id`、`usage_complete`，确保在 Langfuse 顶层 metadata 可筛选。请求根另补 `langfuse.trace.metadata.call_id`，所有 span 均带 environment 与固定 trace 名称。映射后仍检查 64 属性上限；不只依赖无法直接筛选的 metadata.attributes。

LiteLLM 保持 `turn_off_message_logging=True`、`suppress_debug_info=True`，不注册 `langfuse` / `otel` 自动集成，也不自动仪表化 HTTP/SQL。SDK 内部异常日志设置安全过滤器：只保留 logger 名称和固定错误类别，移除 args、exc_info 和任意正文；禁用 verbose logging。导出器自己的日志同样处理，Authorization、端点带参信息均不落日志。

### 2.3 时间与统计口径

| 指标                           | 起止 / 聚合定义                                                                                                    |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------ |
| request.duration_ms            | Agent 已鉴权后根开始 → 原根任务返回/异常，包含分类、选模与收尾                                                     |
| logical.duration_ms            | prepare 开始 → `_finish` 完成/失败；含等待、退避、尝试和收尾                                                       |
| attempt.duration_ms            | Runtime.invoke 前 → 结果及清理完成，含输出校验                                                                     |
| queue_wait_ms                  | 既有每次取槽等待的累计；专用 wait span 显示各段，零 Attempt 也可有等待                                             |
| first_visible_ms（根）         | 根开始 → 主推理首个 text_delta/tool_delta，在转交 sink 前捕获；分类内容不计                                        |
| first_visible_ms（Attempt）    | Attempt 开始 → 首个 text/tool delta；Thinking 元信息不计；无片段/非流式为 null                                     |
| Langfuse completion_start_time | 本 Attempt 首片段发生的 UTC 时间，仅流式 generation 有值；与 first_visible_ms 对应                                 |
| 逻辑主模型成功率               | inference Logical Call completed / 全部已结束 inference Logical Call，包含 canceled/incomplete/failed 与零 Attempt |
| 整轮成功率                     | request completed / 全部已结束 request；单独统计，不用成功 generation 数代替                                       |
| Attempt 成功率 / 重试放大      | 成功 Attempt / 已结束 Attempt；Attempt 数 / 已结束 Logical Call，均明确 scope                                      |

比较视图使用 `environment=local`，默认 24 小时，同窗口分别筛选 `compass.logical` 与 `compass.attempt`，按 Provider UUID / 模型标识分组。未选到模型的根失败属于整轮失败，不能分摊到任意模型。分类阶段单独筛选，不能重复计入主推理调用量。Compass 平台小节提供按该口径计算的只读对比表（见 §2.7），Langfuse 展示 Trace 与趋势。交付固定查询模板与合成金标数据，无任意查询编辑器、定时任务或统计存储。

### 2.4 Token 与估价映射

- 仅 `compass.attempt` 使用 `langfuse.observation.type=generation`。父级 span 仅写 `compass.known_*` / `unknown_attempts` 元信息，不写 Langfuse 原生 usage/cost。
- 既有 RuntimeResult.usage 为 Token 的权威输入；SDK 回调只提供安全回执和可用成本补充。迟到、缺失或重复回调不改变执行、不重复提交 generation；关闭句柄后忽略回调。
- 保守价格策略：仅用量完整、结果已知、SDK 能识别模型价格与用量细类时估价。优先使用回调中的有限非负 `response_cost`；回调尚未返回时，Adapter 复用锁定 LiteLLM 的本地 `completion_cost(completion_response=..., model=...)`，从已归一响应计算一次安全金额，流式用 SDK 标准组装结果。该计算不联网、不自建价格目录、不把响应传给 exporter。模型不存在、用量不全、SDK 无法处理的缓存/细分类定价均保持 unknown。
- `langfuse.observation.usage_details` 仅填已知 input/output，未知键省略；`usage_complete` 与 unknown_usage_attempts 区分零与未知。reasoning 只在 metadata 记录，不额外写进 total。
- `cost_state` 只使用 `complete_estimate` / `unknown`；来源标记为锁定 SDK 与其本地目录版本。已知有限估价时同时写原生 model 与 `cost_details={total:<USD>}`，Langfuse 按显式成本展示。缺估价时这两个原生字段都省略，只在业务 metadata 保留模型标识，防止平台按另一套价格规则补价；固定对比表按 metadata.model 分组。未知禁止发送 `{total:0}`。
- 根/逻辑阶段记录“已知部分”和未知 Attempt 数，不承诺严格总费用。正式按量计费、预算预占和供应商对账独立建设。

### 2.5 LiteLLM 适配与回调边界

现有 `litellm-core==1.106.6` 源码已读。`CustomLogger` 有同步/异步成功和失败入口；`kwargs['callbacks']` 路径可能登记进全局列表，本期禁止每请求修改该列表。回调采用逐调用动态 `success_callback` / `failure_callback` 函数闭包，绑定当前 AttemptReceipt；不依赖后台回调的当前 ContextVar。

回调只从标准字段读取有限数值与枚举，返回即结束，不联网、不新增 span、不 flush，不保存 response / kwargs。Runtime 在自己规范化结果后关闭唯一 Attempt；回调不可用时仍有完整 Attempt 状态和标准用量。平台接入先通过受控 HTTP 夹具验证当前 SDK 的动态回调路径及晚到行为；不得将未命中的回调当作成功接入。

SystemOne 使用现有类型化决策结果提取用量，进入相同 generation 外壳；不强行套用 LiteLLM Chat 回调。`response_model` 不提供时使用 requested_model 作展示标识，另标来源。

### 2.6 OTel 生命周期、导出与自诊断

新增 Agent 内 `observability/` 模块，只服务本 app，不提取共享包。

1. FastAPI lifespan 创建独立 `TracerProvider`、局部 `MeterProvider` / `InMemoryMetricReader` 与单个 BSP，保存 `app.state.observation`。不调用全局 `set_tracer_provider`，不开启自动仪表化。disabled 时使用 NoOp 门面。
2. 使用 ParentBased 根采样；根自行创建，子 span 显式 parent context，整轮决定一致。默认 ratio=1，ratio<1 时 UI 显示 sampled=false 或 sampled=true，任何情况下不声称入库成功。
3. BSP `max_queue_size=512`、`max_export_batch_size=64`、`schedule_delay_millis=1000`。OTLPSpanExporter `timeout=2` 秒，endpoint 固定完整 Trace 地址。后台网络重试只消费 exporter 自身预算，不能影响模型重试。
4. SDK 1.45.2 的 BSP `export_timeout_millis` 未传给 exporter，不能拿该参数控制 HTTP；网络上限必须在 OTLP HTTP exporter 显式设置。
5. `OTEL_PYTHON_SDK_INTERNAL_METRICS_ENABLED=true` 启用 BSP 的公开 Metrics 输出，读取 `otel.sdk.processor.span.queue.size` 与 `otel.sdk.processor.span.processed` 的 error.type 维度；队列满的 SDK 语义为淘汰最旧条目。指标只读取到本地内存，Langfuse 不作为 OTLP Metrics 接收器。
6. 包装 exporter 增加每进程批次失败计数与最近结果枚举，不保存异常字符串。队列深度/丢弃/失败通过平台状态 API 返回；计数在进程重启后归零，不能用作审计。
7. `/healthz` 和 `/readyz` 不依赖 Langfuse。后端地址不可达或运行时认证失败时降级导出；无有效配置时用 NoOp，状态显示 unconfigured。非法 ratio 或明显无效固定地址在显式 enable 时阻止启动，避免静默错误配置；网络不探测启动门禁。
8. 退出先沿原生命周期关闭模型根任务（现有 4.5 秒），再在后台线程调用 provider.shutdown。SDK 原生 BSP 的 join 预算为 30 秒，HTTP exporter 2 秒；本方案观测关闭验证上限 33 秒，整机 Agent grace period 45 秒。到期允许丢弃，不保证关机前全部送达。无每次请求 flush，也不包装一个无法真正终止线程的“2 秒关闭成功”承诺。

### 2.7 API 与客户端契约

关联使用响应头，避免新增/复制 SSE 状态机：

| 头 / API                                                                    | 字段与语义                                                                                                          | 权限 / 兼容                                                               |
| --------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| `X-Compass-Trace-Id`                                                        | 32 位小写 hex；enabled 时发出，含未采样有效 ID                                                                      | BFF 只允许正则匹配值透传；不信任浏览器同名头                              |
| `X-Compass-Trace-Sampled`                                                   | `0` / `1`；关联本轮根采样决定                                                                                       | 客户端单独保存，取消与断流不清除；不放进后续模型消息                      |
| GET `/v1/models/observability`                                    | enabled/configured、mode、sample_ratio、每进程队列深度/容量、drop/error counters、last_export=never/success/failure | Agent `require(context,{manage},platform)`，只接受已有服务令牌+可信上下文 |
| BFF GET `/api/platform/models/observability`（沿现有统一 API 分派） | Agent 安全状态 + Web 固定配置的 Langfuse 项目主页 URL（可空）                                                       | 先平台管理员鉴权；不暴露密钥、内部 ingest 地址和数据库连接                |

状态 DTO 从 Agent `schemas.py` 生成，新增 `ObservabilityStatus` 与 `ModelComparison`，业务响应、CallRecordView 和事件 body 不增加字段。BFF/Hook 在发起调用时先读取响应头，再处理原协议。头缺失表示旧 Agent 或禁用；保留原 call_id。管理入口使用 `http://127.0.0.1:8104/project/<project-id>`；本期不依赖不稳定的 Trace 深链，管理员复制 trace_id 或 call_id 在 Langfuse 搜索。

状态接口返回 `private, no-store`。统计量只允许非负整数和固定枚举。Langfuse 的 session/API Key 与 Compass 会话独立，浏览器不能携服务凭据自动登录。普通租户无法调用平台状态 API；如果平台管理员在租户 Chat 中调试，也要通过平台页面打开 Langfuse。

#### 固定只读模型对比

Agent GET `/v1/models/observability/summary`，经 BFF `/api/platform/models/observability/summary` 转发，两侧复用平台 manage 鉴权。输入仅 `provider_ids`（两个不同 UUID）、`window=1h|24h|7d`；服务端读取已配置 Provider 的安全快照；查询同时匹配 provider_id 和当前模型标识，响应显示这组选择，避免同一 Provider 历史换模后混算。环境固定 local，时间窗口由 Agent UTC 时钟确定并返回起止值，禁止传任意 Langfuse 查询 JSON。

Agent `observability/summary.py` 使用服务端项目 Key 调用 Langfuse `GET /api/public/v2/metrics`，固定 observations 视图。以 `name=compass.logical`、metadata.stage=inference、metadata.provider_id + 当前 metadata.model 双条件和 metadata.status 筛选；每个模型分别取四种已结束状态的 count 与逻辑延迟（平台 latency 单位按固定版 schema 归一为 ms，使用 1 秒夹具验证数值为 1000 ms），另取 `compass.attempt` 的次数、已知 Token/费用和未知数。元信息筛选全部对应 §2.2 的显式顶层键，拒绝按 traceId/userId 做无界 group-by。每模型 4 个逻辑状态查询 + 1 个 Attempt 用量/费用查询 + 2 个未知计数查询，两模型共 14 个固定聚合查询；硬上限 24 个，最多 4 个并行，单次 HTTP 超时 2 秒，总查询预算 8 秒，每个响应最大 256 KiB、最多 100 行。HTTP 无自动重试，无分页全量扫描，结果仅在内存组合。

返回行包含 provider_id、model、logical_count、completed/failed/canceled/incomplete、success_rate、mean_duration_ms、attempt_count、known_input/output_tokens、unknown_usage_attempts、known_estimated_usd、unknown_cost_attempts 和 data_state。分母为 0 返回 success_rate=null；四状态任一查询失败，整行 data_state=unavailable，不展示不完整比例。费用缺价格、用量不全或结果未知的任一 Attempt 使费用汇总只能标“已知部分”，不能显示完整总额。真实平台无数据价格也不能由 SDK 假设补 0。

查询失败返回类型化观测查询错误，页面只影响对比表，不影响模型调用；不把历史结果伪作新查询。UI 显示采样率与“观测数据可能缺失”，不能把无 drop 的当前进程状态用作历史数据完整性证明。无样本显示 PRD 的空状态。统一 `private, no-store`，不新增缓存、计费账本或通用报表服务。

### 2.8 数据所有权与数据库交付

Web 和 Agent 分别管理所属数据库与迁移。本期 Agent/main、Web/main **无结构/受管数据变更**，不新增 migration、SQL 或数据库字段。trace_id 为本轮内存信息；旧记录可用 call_id 检索，导出丢失时只能使用原调用记录。未知未落库 Trace 不回填。

Langfuse 是独立第三方应用栈，PostgreSQL/ClickHouse schema 及内部迁移由固定版本镜像维护；不把其结构导入 Compass ORM，不用业务库账号，Agent/BFF 不直连其表。第三方首次部署及升级需在 `deploy/observability/README.md` 登记镜像版本、上游源、卷、初始化、原生迁移与备份恢复路径；无自研 SQL 副本。

### 2.9 Docker 部署设计

新增 `deploy/compose/observability.yaml`，并入 `compass` 同项目网络，服务前缀统一 `langfuse-`。实施已获用户本地部署授权，运行结果见实施记录：

| 服务                           | 本期选择                                              | 存储 / 对外端口                               |
| ------------------------------ | ----------------------------------------------------- | --------------------------------------------- |
| langfuse-web / langfuse-worker | Langfuse v4.75.0，成对固定版本，固定镜像 digest | Web 仅 127.0.0.1:8104:3000；Worker 不映射宿主 |
| langfuse-postgres              | 独立 PostgreSQL 17 固定 patch/digest                  | 独立卷、账号；无宿主端口                      |
| langfuse-clickhouse            | 官方该 tag 的 ClickHouse 26.3.62.3                    | 数据与日志独立卷，无宿主端口，单节点模式      |
| langfuse-redis                 | Redis 7 固定 patch/digest，认证启用                   | 独立卷；无宿主端口，healthcheck 需认证        |
| langfuse-minio                 | S3 兼容对象存储，固定 digest                          | 独立卷/桶；媒体不开启，无宿主端口             |

完整栈 6 服务，未额外增加 Collector、Prometheus、Grafana 或 Kafka。对象存储用于 Langfuse ingestion。MinIO 仅服务内部事件存储，首版不提供媒体上传，Web/Worker 依赖和 readiness 按固定版官方配置适配。独立 API Key、数据库密码、SALT、ENCRYPTION_KEY、NEXTAUTH_SECRET 由本机初始化生成，绝不沿用上游 CHANGEME。

新增 `scripts/observability.mjs` 与根 `pnpm observability <init|up|status|logs|down>` 为运行入口：

- init 使用 Node crypto 生成私有 `work/observability/stack.env` 与仅 Agent 所需的 `agent.env`，权限 0600，存在时拒绝覆盖；打印安全路径和后续指令，不打印 secret。project id 可使用本机固定生成的 UUID，后台自动初始化仅作用于本栈新数据；旧栈不强制覆盖。
- up 使用显式 compose 文件、项目名与 env-file，启动本栈和健康检查；不停止或重建现有 Compass app。端口占用明确失败，保留旧数据。status/logs 只覆盖观测服务；日志仍可能含第三方运维信息，导出到 work，不提交。
- down 只停止观测服务，保留卷；没有默认 reset / `down -v`。Agent 在栈停止后自动降级导出。
- 根 Compose 的 Agent 增加 optional `env_file: ../../work/observability/agent.env`，只含观测服务 URL/Key/enabled/ratio；删除该配置文件或设置禁用后重建 Agent 可回到原行为。既有 deploy.mjs 仍部署五应用，不能借本 Feature 追加第六个 app 注册。
- 本地 dev 的根任务加载器只在筛选含 Agent 时合并 `agent.env` 的观测白名单键，显式进程环境/根 `.env` 优先；不向 Web/Home 注入 Key、不改变缓存静态检查。或由操作者按 README 将这组配置填入根 `.env`，首版实现优先选择后者以免改任务编排。
- Docker Agent ingest 使用 `http://langfuse-web:3000/api/public/otel/v1/traces`；宿主开发用 `http://127.0.0.1:8104/api/public/otel/v1/traces`。Web 的公开项目入口是单独配置，不复用内部地址。

全部服务放 `observability` profile；Agent 不 `depends_on` Langfuse。选择安全日志轮转和持久卷，初期不承诺定时清除数据。官方本机/VM建议至少 4 核、16 GiB 内存，宿主还需承载 Compass；这是资源规划参考，实际部署验收记录本机分配和运行情况，不能写成已验证最低硬件。

### 2.10 配置清单

| 配置                               | 默认值 / 缺失行为                  | 作用域与生效                                               |
| ---------------------------------------- | ---------------------------------- | ---------------------------------------------------------- |
| COMPASS_OBSERVABILITY_ENABLED            | false；禁用门面，无网络            | Agent 启动                                                 |
| COMPASS_OBSERVABILITY_SAMPLE_RATIO       | 1，合法 0～1                       | Agent 启动                                                 |
| COMPASS_LANGFUSE_BASE_URL                | 空；enable 时为空显示 unconfigured | Agent 服务端；固定部署配置                                 |
| COMPASS_LANGFUSE_PUBLIC_KEY / SECRET_KEY | 空；不完整时 NoOp + unconfigured   | Agent SecretStr，不在响应或日志输出                        |
| COMPASS_OBSERVABILITY_ENVIRONMENT        | local / showcase；部署约束枚举     | Agent 启动，不接受浏览器覆盖                               |
| COMPASS_LANGFUSE_PROJECT_URL             | 空时禁用打开                       | Web 服务端，固定 127.0.0.1:8104 的项目 URL，本机 HTTP 例外 |
| OTEL_PYTHON_SDK_INTERNAL_METRICS_ENABLED | enabled 时 true                    | 初始化前设置，仅本地 SDK 自诊断                            |

队列、批次、属性上限、网络与关闭预算先为模块常量，不堆叠可配项。地址校验禁止用户名密码、query、fragment；本地允许固定 loopback/Compose 服务名 HTTP，未来远程必须 HTTPS，不能从调用参数改变目标。

## 3. 风险与最小验证

| 风险 / 触发                               | 后果                     | 处理与验证                                                                                |
| ----------------------------------------- | ------------------------ | ----------------------------------------------------------------------------------------- |
| 自动回调采全文或 global callback 累积     | 泄露、跨请求串线         | 禁自动 Langfuse 集成；动态函数闭包；受控并发回调、敏感哨兵出口测试                        |
| 输出后 SDK 回调才触发                     | 丢成本回执或重复计费观测 | Runtime 结果为权威，late callback 忽略；不等待回调，不凭回调新建 generation               |
| OTel shutdown / exporter timeout 理解错误 | 优雅退出卡住             | 锁定 SDK 源码、公有参数；测试后台慢导出与 33 秒边界，不用 BSP export_timeout 代替网络限制 |
| 缺失字段被 Langfuse UI 聚合为 0           | 费用低估、错误成功率     | 根/逻辑/尝试分层，完整性 metadata；金标 API 核对与平台保存视图；不承诺计费                |
| 导出队列满导致父 span 缺失                | Trace 局部断链           | 自诊断与 UI 警示、保持模型路径；不为完整性加同步写库                                      |
| 共享 Langfuse 项目当成租户隔离            | 跨租户观察               | 仅管理员账号；无租户自动授权；不把 metadata 过滤当授权                                    |
| 本地栈消耗资源                            | Compass 和平台争抢内存   | 可选 profile、独立卷、资源规划与实际 Docker 验收；未部署不能计作通过                      |

## 4. 兼容、发布与恢复

| 组合                     | 行为与顺序                                              |
| ------------------------ | ------------------------------------------------------- |
| 新 Web + 旧 Agent        | 无观测头/管理端点时显示未启用或不可用，模型功能沿原链路 |
| 旧 Web + 新 Agent        | 忽略新响应头；原业务 body/SSE 不变                      |
| 新 Agent + Langfuse 停机 | 后台导出失败，原 readiness / 模型调用正常               |
| 新状态/对比 DTO          | 生成 JSON/TS，Agent/BFF 同步；不可手改生成文件          |

首次先部署 Langfuse 栈、初始化并确认独立登录和 Key，再按部署类型配置 Agent，最后部署 Web 入口。Compass 无数据库迁移。回退先禁用遥测并回退代码，不删除 Langfuse 卷。Langfuse 版本升级另做备份、原生迁移和恢复演练；数据库已升级时禁止仅回退镜像，恢复到新卷后切换，保留故障卷。

## 5. 分布式观测

覆盖 [PRD](PRD.md) 的 FR-990-13～15、AC-990-15～18。

- Resource 显式增加 service.namespace=compass、service.instance.id（默认启动 UUID，配置可指定）；环境允许 local/test/staging/production/showcase。属性白名单增加 instance_id，所有业务 span 映射为可筛选顶层 metadata。
- model_api 在既有 trusted_context 和动作权限验证完成后创建根句柄，使用显式 W3C Propagator 提取合法且长度受限的 traceparent/tracestate；不读 baggage。无效 carrier 创建本地新根，不拒绝模型任务，不记录原头。边界之内服务调用和任务消息可用 `scope.carrier()` 得到纯上下文 carrier。浏览器输入头始终由 BFF 丢弃。
- 根/子 span 使用显式 parent Context，ParentBased 继承可信远程采样决定；不依赖全局 TracerProvider 或当前任务变量。HTTP 和消息工具统一实现，无实际 Worker 业务队列新增。
- tracestate 只用于可信内部传播；GuardedExporter 以保留 ID/采样的安全 SpanContext 导出，清除原生 trace_state vendor 文本，防止通过标准上下文字段旁路元信息白名单。

### 5.1 实现细节

- ModelService 复用原 prepare 得到的 Provider 快照绑定模型与版本；观测不增加业务库读取。准备失败没有模型快照时只按请求/Provider 关联。
- Observation 同时持有安全 metadata、终态、首片段与成本回执，不另建 types.py 或第二份回执状态。代码设计中的分离类型保留为职责说明，实施类型见源码。
- Attempt 继承逻辑阶段，固定模型对比同时筛选 `stage=inference`。Langfuse v4.75.0 的 latency 原生为毫秒；两个进程的 1 秒金标验证数值约为 1000 ms。
- 逐请求 SDK 成本计算和流组装受异常隔离；明确缺失的缓存细分类别保持未知估价。
- Compose 镜像全部固定 digest；MinIO 使用同版上游 Compose 的 Chainguard 发行，避免依赖已不可拉取的旧 MinIO Hub 标签。Web/Worker 显式绑定 `0.0.0.0`；v4 写入和 Metrics v2 模式显式开启。
- 私有配置分为 stack.env / agent.env / web.env；Web 文件只有固定公开项目入口。部署、存储与备份恢复见 Compass 仓库的 `deploy/observability/README.md`。
- 状态返回 instance_id，比较保持跨实例查询；本期不将某个实例的队列状态称为全局状态。正常日志通过安全 JSON formatter输出事件、错误类别、实例编号与可得关联编号，不记录正文/异常原文。

## 架构图与源码导读

### 0. 先读懂 OTel 的几个术语

```mermaid Trace、Span 与上下文
flowchart TB
    T["Trace：一轮跨阶段的调用链<br/>共享同一个 Trace ID"] --> R["根 Span · compass.request<br/>记录起止时间和终态"]
    R --> L["子 Span · compass.logical<br/>一次模型逻辑调用"]
    L --> A["孙 Span · compass.attempt<br/>一次实际尝试<br/>有独立 Span ID"]
    A --- F["Attributes：模型、状态、用量<br/>Event：Span 内的带时间戳记录"]
    R -.-> P["SpanContext<br/>Trace ID · Span ID · 采样标志<br/>用 W3C Trace Context 跨服务传播"]
```

下面用一次模型调用展示 `ExportTraceServiceRequest` 的 OTLP JSON 结构。三个 Span 共享同一个 `traceId`，通过 `parentSpanId` 串成「请求 → 逻辑调用 → 实际尝试」。样例选取了部分业务属性，Compass 实际用 HTTP 发送同一结构的二进制 Protobuf。

```json OTLP Trace 数据样例
{
  "resourceSpans": [
    {
      "resource": {
        "attributes": [
          { "key": "service.name", "value": { "stringValue": "compass-agent" } },
          { "key": "service.namespace", "value": { "stringValue": "compass" } },
          { "key": "service.instance.id", "value": { "stringValue": "demo-agent-01" } },
          { "key": "service.version", "value": { "stringValue": "0.1.0" } },
          { "key": "deployment.environment.name", "value": { "stringValue": "local" } }
        ],
        "droppedAttributesCount": 0
      },
      "scopeSpans": [
        {
          "scope": { "name": "compass.observability" },
          "spans": [
            {
              "traceId": "4bf92f3577b34da6a3ce929d0e0e4736",
              "spanId": "1111111111111111",
              "parentSpanId": "",
              "traceState": "",
              "flags": 256,
              "name": "compass.request",
              "kind": 1,
              "startTimeUnixNano": "1780000000000000000",
              "endTimeUnixNano": "1780000001500000000",
              "attributes": [
                { "key": "langfuse.observation.type", "value": { "stringValue": "span" } },
                {
                  "key": "langfuse.observation.metadata.status",
                  "value": { "stringValue": "completed" }
                }
              ],
              "events": [],
              "links": [],
              "droppedAttributesCount": 0,
              "droppedEventsCount": 0,
              "droppedLinksCount": 0,
              "status": { "code": 0 }
            },
            {
              "traceId": "4bf92f3577b34da6a3ce929d0e0e4736",
              "spanId": "2222222222222222",
              "parentSpanId": "1111111111111111",
              "traceState": "",
              "flags": 256,
              "name": "compass.logical",
              "kind": 1,
              "startTimeUnixNano": "1780000000100000000",
              "endTimeUnixNano": "1780000001450000000",
              "attributes": [
                { "key": "langfuse.observation.type", "value": { "stringValue": "span" } },
                {
                  "key": "langfuse.observation.metadata.stage",
                  "value": { "stringValue": "inference" }
                },
                {
                  "key": "langfuse.observation.metadata.queue_wait_ms",
                  "value": { "intValue": "25" }
                }
              ],
              "events": [],
              "links": [],
              "droppedAttributesCount": 0,
              "droppedEventsCount": 0,
              "droppedLinksCount": 0,
              "status": { "code": 0 }
            },
            {
              "traceId": "4bf92f3577b34da6a3ce929d0e0e4736",
              "spanId": "3333333333333333",
              "parentSpanId": "2222222222222222",
              "traceState": "",
              "flags": 256,
              "name": "compass.attempt",
              "kind": 1,
              "startTimeUnixNano": "1780000000200000000",
              "endTimeUnixNano": "1780000001400000000",
              "attributes": [
                { "key": "langfuse.observation.type", "value": { "stringValue": "generation" } },
                {
                  "key": "langfuse.observation.metadata.first_visible_ms",
                  "value": { "doubleValue": 268.5 }
                },
                {
                  "key": "langfuse.observation.metadata.usage_complete",
                  "value": { "boolValue": true }
                },
                {
                  "key": "langfuse.observation.usage_details",
                  "value": { "stringValue": "{\"input\":96,\"output\":24}" }
                }
              ],
              "events": [],
              "links": [],
              "droppedAttributesCount": 0,
              "droppedEventsCount": 0,
              "droppedLinksCount": 0,
              "status": { "code": 0 }
            }
          ]
        }
      ]
    }
  ]
}
```

| 看哪个字段                                       | 读出什么                                                                                                                                             |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `resourceSpans[].resource`、`scopeSpans[].scope` | 哪个服务实例产生数据，以及哪段埋点代码记录了它                                                                                                       |
| `traceId`、`spanId`、`parentSpanId`              | 同一 Trace 共享 32 位十六进制 `traceId`。Span ID 是 16 位十六进制，根 Span 的父 ID 为空                                                              |
| `startTimeUnixNano`、`endTimeUnixNano`           | 纳秒时间戳在 JSON 中写成十进制字符串。样例里的 Attempt 持续 1.2 秒                                                                                   |
| `kind`、`status`、`flags`                        | `kind: 1` 表示内部操作。Compass 在成功时保留 OTel 默认状态 `code: 0`，业务完成状态写入 metadata。`flags` 是位字段，样例采用当前 SDK 的本地上下文编码 |
| `attributes`、`events`、`links`                  | 属性值带类型。Event 是 Span 内的带时间戳记录，Link 可引用其他 Span。Compass 此处只使用属性，两个数组为空                                             |

```mermaid Traces、Metrics 与 Logs 的三条路径
flowchart TB
    O["OpenTelemetry · 统一采集与导出接口"] --> T["Traces<br/>TracerProvider → Tracer → Span"]
    O --> M["Metrics<br/>MeterProvider → Meter → Instrument"]
    O --> L["Logs<br/>独立的日志记录信号"]
    T --> E["Compass：OTLP/HTTP + protobuf<br/>Langfuse 保存调用树并聚合模型数据"]
    M --> C["Compass：SDK 内部队列指标<br/>InMemoryMetricReader → 当前实例状态"]
    L --> S["Compass：Python logging<br/>安全 JSON → 进程 / 容器日志"]
```

| 术语                        | 含义                                                              | 在 Compass 中怎么看                                                                                |
| --------------------------- | ----------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| Meter / Instrument / Metric | Meter 创建 Counter、Histogram 等 Instrument，测量值经聚合形成指标 | 这里读取 OTel SDK 已记录的队列深度与处理结果。模型成功率和耗时由 Langfuse 查询 Span 样本得到       |
| Resource                    | 一组描述数据来源的属性                                            | `service.name`、`service.instance.id`、版本与环境帮助区分多个 Agent 实例                           |
| Sampler                     | Span 创建时决定记录与采样                                         | 新根按比例采样，可信远程父链路的采样决定由 `ParentBased` 继承                                      |
| Span Processor / Exporter   | Processor 处理 SDK 内已结束的 Span，Exporter 将批次送出           | `BatchSpanProcessor` 管队列与批次，`GuardedExporter` 核验内容，`OTLPSpanExporter` 发送             |
| OTLP / Observation          | OTLP 是遥测数据传输协议，Observation 是 Langfuse 的观测记录       | 普通 Span 映射为 `SPAN`。进入 Adapter 的 Attempt 映射为 `GENERATION`，可带模型输入输出、用量与估价 |

### 目标

| 核心问题                       | 实现目标                                 | 量化指标（设计目标）                                                |
| ------------------------------ | ---------------------------------------- | ------------------------------------------------------------------- |
| 一轮请求跨分类、选模和生成     | 用 Trace ID 关联所有阶段和实际尝试       | 每次接入服务建立 1 个请求 Span，每次实际尝试有 1 个独立 Span        |
| 慢请求、失败与恢复难排查       | 拆出排队、退避、尝试、首个可见片段和收尾 | 各 Span 各自计时，首片段时间用单调时钟计算                          |
| 导出失败挤占请求资源           | 按进程异步批量上报                       | 队列 512 Span，每批最多 64，调度间隔 1 秒，HTTP 导出器 timeout 2 秒 |
| 多实例比较与单实例诊断容易混淆 | 一处聚合模型数据，逐实例查看队列健康     | 比较两个模型、三个可选窗口，发出 14 个固定查询                      |

### 1. 方案概述

#### 1.1 职责分工

| 模块                                      | 谁负责什么                                                           |
| ----------------------------------------- | -------------------------------------------------------------------- |
| Web / BFF                                 | 原鉴权、响应头校验与透传、编号复制、管理员状态和模型对比入口         |
| Agent HTTP / RoutingService               | 建立请求 Span、接收可信 Trace Context，记录分类和选模关联            |
| ModelService / ReliableExecutor / Runtime | 维护 Logical Call 和 Attempt，记录等待、首片段、输出、失败和写库收尾 |
| Agent `observability/`                    | 明确父子关系、构造安全字段、装配 OTel SDK、导出 Span 并查询固定指标  |
| Langfuse                                  | 接收 OTLP、处理入库、展示 Trace 与 Generation、提供查询 API          |

#### 1.2 Compass 整体架构

```mermaid Compass 应用层与观测层
flowchart TB
    UI["Chat / 模型能力测试"] --> B["Compass Web / BFF"]
    B --> A["Compass Agent<br/>HTTP → Routing → ModelService → Runtime"]
    A --> P["LiteLLM / SystemOne → 模型提供方"]
    A --> DB["Agent 业务库<br/>调用记录与执行状态"]
    A --> O["进程内 Observation + OTel SDK"]
    O --> LF["本地 Langfuse<br/>调用树、Generation、指标聚合"]
    B -.->|"管理员状态与对比"| A
    A -.->|"固定 Metrics v2 查询"| LF
```

#### 1.3 OTel 工作流程

```mermaid 从埋点到 OTLP 批量上报
flowchart TB
    C["已鉴权入口提取远程 Context<br/>或创建本地 Trace"] --> S["独立 TracerProvider<br/>Resource + ParentBased 采样"]
    S --> R{"当前 Span 记录吗？"}
    R -->|"否"| N["保留链路 ID 与采样标志<br/>继续模型执行"]
    R -->|"是"| W["start_span → 写白名单字段 → end<br/>子 Span 继承父上下文"]
    W --> B["BatchSpanProcessor<br/>512 Span 队列 · 64 / 批 · 1 秒调度"]
    B --> G["GuardedExporter<br/>检查 scope、属性、正文策略与事件，清除导出 tracestate"]
    G --> E["OTLPSpanExporter<br/>HTTP/protobuf · 项目 Basic 鉴权 · timeout 2 秒"]
    E --> L["Langfuse 接收端点"]
    B -.-> M["本机队列深度与丢弃计数"]
    G -.-> M
    E -.-> D["失败计数与限频 JSON 日志"]
```

| 多实例场景           | Context 处理                                                                                            |
| -------------------- | ------------------------------------------------------------------------------------------------------- |
| 内部 HTTP 或消息载体 | `carrier()` 注入 W3C 头，接收端在服务鉴权和动作授权后提取。下游沿用 Trace ID，生成自己的 Span ID        |
| 实例 A 调用实例 B    | 两边向同一项目上报。父子 Span 还原一条链路，`service.instance.id` 标记各自来源                          |
| 浏览器和供应商边界   | BFF 丢弃浏览器传入的 Trace Context，模型供应商出站请求省略内部 carrier，OTLP 出口去掉 `tracestate` 文本 |

#### 1.4 Langfuse 整体架构

```mermaid 本地 Langfuse 六服务与读写路径
flowchart TB
    A["Compass Agent · OTLP 导出"] -->|"POST /api/public/otel/v1/traces"| W
    U["浏览器 · 127.0.0.1:8104<br/>Compass Agent · Metrics v2 查询"] -->|"控制台 / 公开 API"| W
    subgraph LF["Langfuse v4.75.0"]
      W["Langfuse Web · 接收与查询"]
      Q["Redis · 任务队列 / 缓存"]
      S["MinIO · 摄取事件对象"]
      K["Langfuse Worker · 异步处理"]
      C["ClickHouse · Span / Generation 数据"]
      P["PostgreSQL · 账号 / 项目 / 配置"]
      W -->|"存事件对象"| S
      W -->|"排入处理任务"| Q
      Q -->|"消费任务"| K
      K -->|"读取事件对象"| S
      K -->|"写观测记录"| C
      W -->|"查 Trace 与聚合"| C
      W -->|"鉴权与项目配置"| P
    end
```

宿主机用 `http://127.0.0.1:8104`。Compose 网络内，Agent 用 `http://langfuse-web:3000`。两个地址指向同一套 Langfuse Web，Trace 数据与 Compass 业务记录分别持久化。

### 2. 一张完整的埋点地图

![Compass 模型调用埋点地图](visuals/diagram-01.svg)

读图时，沿绿色连线看 Span 父子关系。入口下面的分类、路由、主推理和能力测试按场景出现。分类、推理和测试复用同一个 Logical Call 执行结构，图中把这套子树展开一次。重试产生新的 Attempt Span。出口虚线汇集各阶段已结束的 Span。流式首片段、I/O 和费用都是 Attempt 上的属性，未额外创建 Span。

#### 2.1 按埋点类型看源码

每条中文注释放在对应源码的上一行，解释这行在观测流程中的作用。

| 类型            | 写入时机与方法                                                                           | 上报或读取方式                                       |
| --------------- | ---------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| 生命周期 Span   | `root()` / `child()` 创建，`complete()` 记业务终态，`end()` 提交已结束 Span              | 共用 BSP → GuardedExporter → OTLP → Langfuse         |
| 普通属性与状态  | `set()` 写业务 metadata，`native()` 写 Langfuse 类型、级别等原生字段                     | 随所属 Span 上报                                     |
| 计时与分支      | wait / backoff 各有开始与结束，首次可见片段写 Attempt 时间，logical 汇总 `queue_wait_ms` | Span 起止时间与属性一起上报                          |
| Generation 数据 | 进入 Adapter 前采集输入，Attempt 收尾采集已组装输出，写入已知用量和估价                  | `compass.attempt` 上报为 Generation                  |
| SDK Metrics     | SDK 记录队列深度、溢出及关闭丢弃，Pipeline 汇总出口失败                                  | `InMemoryMetricReader` → Agent 状态 API → 平台管理页 |
| 诊断 Logs       | 导出失败限频记录，正常关机写计数                                                         | Python logger → 进程 / 容器日志                      |

##### 生命周期与终态

入口把句柄放在请求和服务上。逻辑调用在 `prepare()` 前开启，因此配置或授权快照失败也会留下阶段记录。`_finish()` 围住原记录收尾并结束逻辑 Span。

```python model_api.py · 请求根与结束
# 为已通过鉴权的模型请求建立根观测句柄。
def start_observation(request, service, context, call_id):
    # 从应用状态取进程启动时创建的 Observer。
    observer = getattr(request.app.state, "observation", None)
    # 观测已启用且 Tracer 可用时才建 Span。
    if observer and observer.tracer:
        # 根据调用编号、可信身份和请求头创建根 Span。
        service.root_observation = observer.root(call_id, context, request.headers)
        # 将同一句柄挂到请求上，供响应头和执行收尾使用。
        request.state.model_observation = service.root_observation


# 用请求根 Span 包住实际模型任务。
async def observed_run(request, coroutine):
    # 取入口保存在请求状态里的句柄。
    observation = getattr(request.state, "model_observation", None)
    # 进入任务执行范围，统一处理正常完成和异常。
    try:
        # 等待模型任务返回业务结果。
        result = await coroutine
        # 句柄存在时同步这次调用的最终状态。
        if observation:
            # 记录业务终态与安全错误码。
            observation.complete(result.status, result.error_code)
        # 把原业务结果交回调用方。
        return result
    # 捕获异常和任务取消，随后交回原错误处理路径。
    except BaseException as exc:
        # 观测启用时记录异常对应的终态。
        if observation:
            # 为失败或取消填入待上报的状态。
            observation.complete(
                # 主动取消与一般执行失败用不同状态区分。
                "canceled" if isinstance(exc, asyncio.CancelledError) else "failed",
                # 沿用已有错误码，缺少时使用内部错误码。
                getattr(exc, "code", "internal_error"),
            # 保存根观测的异常终态。
            )
        # 继续抛出原异常，由业务入口处理。
        raise
    # 成功、失败和取消均进入收尾。
    finally:
        # 有根 Span 时才执行结束操作。
        if observation:
            # 结束根 Span，让 SDK 处理已完成的记录。
            observation.end()
```

```python models/service.py · Logical Call
# 进入模型准备阶段，兼容原期限和授权参数。
async def prepare(self, call_id, provider_id, request, context, *, deadline=None, grant=None):
    # 先取观测句柄，让后续准备失败也落在这个阶段内。
    observation = (
        # 从请求根创建子 Span。
        self.root_observation.child(
            # 用固定名称标识一次模型逻辑调用。
            "compass.logical",
            # 关联业务调用编号。
            call_id=str(call_id),
            # 记录本次选择的 Provider 编号。
            provider_id=str(provider_id),
            # 区分分类、主推理和能力测试等阶段。
            stage=self.stage,
            # 保留来自可信上下文的调用用途。
            purpose=context.purpose,
        # 完成子 Span 创建所需的初始属性。
        )
        # 存在请求根时创建子 Span。
        if self.root_observation
        # 无请求根时沿用原业务路径。
        else None
    # 保存这一分支产生的观测句柄。
    )
    # 已创建逻辑 Span 时建立本轮索引。
    if observation:
        # 按 call_id 保存句柄，供执行与收尾阶段取用。
        self.observations[call_id] = observation
    # 围住原准备逻辑并跟踪异常。
    try:
        # 运行原准备流程，解析并校验模型快照。
        prepared = await self._prepare(
            # 透传原有的期限和授权参数。
            call_id, provider_id, request, context, deadline=deadline, grant=grant
        # 等待准备完成后拿到实际使用的配置。
        )
        # 准备成功后补全已解析的模型信息。
        if observation:
            # 把快照字段写进逻辑 Span 的 metadata。
            observation.set(
                # 记录最终请求的模型标识。
                model=prepared.spec.api_model,
                # 记录所用 Provider 配置版本。
                config_version=prepared.spec.config_version,
                # 记录模型绑定版本，便于定位配置切换。
                binding_version=prepared.spec.binding_version,
            # 一次写入准备好的快照字段。
            )
        # 将原准备结果交给执行器。
        return prepared
    # 准备阶段报错或取消时提前收尾。
    except BaseException as exc:
        # 逻辑 Span 存在时才更新观测。
        if observation:
            # 记录尚未开始 Attempt 时的终态。
            observation.complete(
                # 通过取消异常区分取消与失败。
                "canceled" if isinstance(exc, asyncio.CancelledError) else "failed",
                # 选取安全错误码，避免记录异常正文。
                getattr(exc, "code", "internal_error"),
            # 保存逻辑调用的异常终态。
            )
            # 关闭这个未进入执行的逻辑 Span。
            observation.end()
            # 从索引移除已结束的句柄。
            self.observations.pop(call_id, None)
            # 请求根仍存在时同步整体异常。
            if self.root_observation:
                # 在根 Span 上标记准备阶段的失败或取消。
                self.root_observation.complete(
                    # 沿用同一终态口径。
                    "canceled" if isinstance(exc, asyncio.CancelledError) else "failed",
                    # 将同一个安全错误码带到请求根。
                    getattr(exc, "code", "internal_error"),
                # 完成请求根终态更新。
                )
        # 让业务入口继续处理原异常。
        raise
```

```python models/service.py · finalize
# 包住一次模型结果的持久化收尾。
async def _finish(self, result, sent):
    # 移除并取得此前保存的逻辑调用句柄。
    observation = self.observations.pop(result.call_id, None)
    # 用独立子 Span 测量结果收尾耗时。
    finalize = observation.child("compass.finalize") if observation else None
    # 把原记录写入放在这段生命周期内。
    try:
        # 等待原收尾逻辑，并把它的返回值交给调用方。
        return await self._finish_record(result, sent)
    # 返回或抛出异常前统一结束观测。
    finally:
        # 有收尾 Span 时先处理子节点。
        if finalize:
            # 写入业务结果状态和安全错误码。
            finalize.complete(result.status, result.error_code)
            # 关闭收尾 Span，使其进入导出流程。
            finalize.end()
        # 有逻辑句柄时再结束父节点。
        if observation:
            # 使用收尾后的业务终态，避免后续外围状态覆盖。
            observation.complete(result.status, result.error_code, authoritative=True)
            # 关闭逻辑 Span，保留整次调用耗时。
            observation.end()
```

##### 普通属性、耗时与重试

选模后写入分类、场景、模型和版本。wait 包住取并发槽，backoff 包住重试前等待。Executor 的流式预览只用首个正文或工具片段触发 `first_visible()`。Attempt 的时间写入原生 `completion_start_time`，首片段耗时同时写到 Attempt 和本轮请求。

```python routing/service.py · 路由属性
# 本轮建立了路由 Span 时才写入选择结果。
if route_observation:
    # 将路由决策整理成可筛选的 metadata。
    route_observation.set(
        # 记录分类器判定的业务类别。
        category_id=intent.category_id,
        # 记录命中的业务场景。
        scene_id=intent.scene_id,
        # 记录用于选模的任务难度。
        difficulty=features.difficulty,
        # 区分固定选模和自动选模。
        mode=selection.mode,
        # 保留本次选择的规则原因。
        reason=reason,
        # 记录实际选中的 Provider 编号。
        provider_id=str(provider_id),
        # 记录该 Provider 快照里的模型名。
        model=view.api_model,
        # 记录解释分类结果所用的字典版本。
        dictionary_version=catalog()[0],
        # 记录这次决策所用的路由策略版本。
        routing_version=POLICY.version,
    # 提交这次路由选择的属性。
    )
```

```python llm/executor.py · 并发槽等待
# 用事件循环的单调时钟记录排队起点。
queued = loop.time()
# 在逻辑 Span 下建等待节点。
wait_observation = observation.child("compass.wait") if observation else None
# 覆盖等待并发槽的过程。
try:
    # 沿用模型调用的截止时间限制排队。
    async with asyncio.timeout_at(deadline):
        # 等待取得一个并发槽，随后才能开始尝试。
        await self.gate.slots.acquire()
# 排队中遇到取消、超时等异常时更新观测。
except BaseException as exc:
    # 只在已创建等待 Span 时写终态。
    if wait_observation:
        # 为这段排队过程记录结束原因。
        wait_observation.complete(
            # 取消记为 canceled，其余异常记为 failed。
            "canceled" if isinstance(exc, asyncio.CancelledError) else "failed",
            # 只有超时分支在这里补 model_timeout。
            "model_timeout" if isinstance(exc, TimeoutError) else None,
        # 保存这次排队的异常状态。
        )
    # 把异常交回执行器的原有处理路径。
    raise
# 无论是否取得并发槽，都结算本次等待。
finally:
    # 把经过的时间换算成毫秒，累加到逻辑调用。
    run.queue_wait_ms += max(0, int((loop.time() - queued) * 1000))
    # 等待 Span 存在时需要关闭。
    if wait_observation:
        # 结束排队 Span，保留实际等待区间。
        wait_observation.end()
```

```python llm/executor.py · 退避与终态
# 为重试前等待创建单独的退避 Span。
backoff = observation.child("compass.backoff") if observation else None
# 用此范围记录等待如何结束。
try:
    # 退避仍受原逻辑调用截止时间约束。
    async with asyncio.timeout_at(deadline):
        # 等待本次策略选定的退避时间。
        await self.sleep(delay)
# 退避中取消或到期时进入异常收尾。
except BaseException as exc:
    # 有退避句柄时才更新观测。
    if backoff:
        # 为退避节点记录异常终态。
        backoff.complete(
            # 区分外部取消和其他失败。
            "canceled" if isinstance(exc, asyncio.CancelledError) else "failed",
            # 到期时给出模型超时的安全错误码。
            "model_timeout" if isinstance(exc, TimeoutError) else None,
        # 保存退避节点的异常结果。
        )
    # 交回原异常，由上层决定逻辑调用如何结束。
    raise
# 正常等待完成和异常分支都经过此处。
finally:
    # 确认创建过退避 Span。
    if backoff:
        # 结束退避节点并记录完整等待区间。
        backoff.end()
```

```python llm/executor.py · 流式正文与工具事件
# 接收 Runtime 产生的一个流式事件。
async def preview(event):
    # 允许回调更新执行器持有的正文已暴露标记。
    nonlocal content_exposed
    # 只用正文或工具片段判断用户可见输出。
    if event.type in {"text_delta", "tool_delta"}:
        # 标记本次执行已有可见内容，供恢复策略使用。
        content_exposed = True
        # 同步写入逻辑执行状态。
        run.content_exposed = True
        # 有当前 Attempt 句柄时才埋点。
        if active_observation:
            # 尝试记录首个可见片段，后续片段由句柄忽略。
            active_observation.first_visible()
    # 确认调用方提供了流式事件接收器。
    assert emit is not None
    # 继续把原事件推给调用方。
    await emit(event)
```

```python observer.py · 首个可见片段时间
# 记录当前 Attempt 首个可见正文或工具片段。
def first_visible(self):
    # 只有首个可见片段会写入时间。
    if self.first_ns is None:
        # 以单调时钟记录事件时点，供耗时计算。
        self.first_ns = monotonic_ns()
        # 从 Attempt 起点计算首片段延迟并换算为毫秒。
        self.set(first_visible_ms=(self.first_ns - self.started_ns) / 1e6)
        # 另记 UTC 时刻，供 Langfuse 的 Generation 展示。
        self.native("completion_start_time", datetime.now(UTC).isoformat())
        # 检查本轮请求是否已记录更早的可见片段。
        if self.root.first_ns is None:
            # 将本次首片段时点同步到请求根。
            self.root.first_ns = self.first_ns
            # 按整轮请求起点计算首片段延迟。
            self.root.set(first_visible_ms=(self.first_ns - self.root.started_ns) / 1e6)
```

##### Generation、输入输出与用量

Executor 创建新 Attempt 后把句柄传给 Runtime。`capture_input()` 位于 Adapter 调用前，`finish_attempt()` 位于 Runtime 清理后。取消路径也使用 `RuntimeCancelled.result` 收尾。

```python llm/executor.py · Attempt 与取消结果
# 为即将执行的这一次尝试准备观测句柄。
active_observation = (
    # 在当前逻辑调用下建子 Span。
    observation.child(
        # 固定 Span 名称，方便筛选实际尝试。
        "compass.attempt",
        # 用本次尝试编号区分初次请求和重试。
        attempt_id=str(attempt_id),
        # 关联所属的业务逻辑调用编号。
        call_id=str(request.context.call_id),
        # 继承父节点的业务阶段，缺省时归为测试。
        stage=observation.metadata.get("stage", "test"),
        # 记录本次使用的 Provider。
        provider_id=str(request.access.spec.provider_id),
        # 记录本次请求的模型名。
        model=request.access.spec.api_model,
        # 记录执行所用的配置版本。
        config_version=request.access.spec.config_version,
        # 记录本次执行的模型绑定版本。
        binding_version=request.access.spec.binding_version,
        # 标明所用 Adapter，便于排查适配差异。
        adapter=request.access.spec.adapter,
    # 完成 Attempt 初始属性的传入。
    )
    # 父逻辑 Span 存在时才开启观测。
    if observation
    # 无父观测时继续正常执行模型。
    else None
# 保存本次尝试的可选句柄。
)
# 围住 Runtime 执行以获取取消时的结果。
try:
    # 发起单次 Runtime 调用。
    result = await self.runtime.invoke(
        # 传入已准备好的模型调用参数。
        invocation,
        # 流式请求启用预览回调以记录首片段。
        preview if emit else None,
        # 只在有 Attempt 句柄时传入观测参数。
        **({"observation": active_observation} if active_observation else {}),
    # 等待单次执行返回或抛出取消异常。
    )
# Runtime 取消异常携带部分结果与清理状态。
except RuntimeCancelled as exc:
    # 保留取消发生后资源是否已清理。
    cleanup_confirmed = exc.result.cleanup_confirmed
    # 先把已知尝试结果加入逻辑执行摘要。
    run.observe(attempt_id, exc.result, started_at)
    # 有 Attempt Span 时同步取消后的结果。
    if active_observation:
        # 以 Runtime 提供的取消结果完成 Attempt 上报。
        active_observation.finish_attempt(exc.result)
    # 继续传播取消，让外层按原规则收尾。
    raise
# 正常返回时保存该次执行的清理结果。
cleanup_confirmed = result.cleanup_confirmed
# 将本次尝试写入逻辑执行摘要。
run.observe(attempt_id, result, started_at)
# 有 Attempt 句柄时进入观测收尾。
if active_observation:
    # 根据单次运行结果完成并结束 Attempt Span。
    active_observation.finish_attempt(result)
```

```python llm/runtime.py · Adapter 前采集
# 标记已通过前置校验，即将进入 Adapter。
adapter_started = True
# 有观测句柄时才调用正文采集入口。
if observation is not None:
    # 由采集策略决定是否投影、过滤并记录输入。
    observation.capture_input(request)
# 执行原 Adapter 调用并等待模型输出。
output = await adapter.invoke(request, session)
```

```python observer.py · Generation 上报字段
# 把一次 Runtime 执行结果转换成 Attempt 的观测字段。
def finish_attempt(self, result):
    # 先判断执行是否真正进入模型 Adapter。
    if not result.adapter_started:
        # A pre-adapter validation is an execution phase, with no generation or charge.
        # 前置校验失败时，确认有可更新的 Span。
        if self.span:
            # 将这类提前结束的 Span 标记为校验节点。
            self.span.update_name("compass.validation")
        # 同步校验结果和安全错误码。
        self.complete(result.status, result.error.code if result.error else None)
        # 结束校验 Span。
        self.end()
        # 到此结束校验分支，跳过 Generation 字段。
        return
    # 进入 Adapter 后按 Langfuse Generation 类型记录。
    self.native("type", "generation")
    # 按正文策略写入组装后的可见输出。
    self.capture_output(result)
    # 批量记录单次执行的关键结果。
    self.set(
        # 记录请求是否发给了上游供应商。
        sent=result.upstream_sent,
        # 标记供应商最终结果是否未知。
        outcome_unknown=result.upstream_outcome_unknown,
        # 记录本次执行所占资源是否确认清理。
        cleanup_confirmed=result.cleanup_confirmed,
        # 保留已知的思考 Token 数，不重复加入输出用量。
        reasoning_tokens=result.usage.reasoning_tokens,
    # 完成本次执行结果的 metadata 写入。
    )
    # 从 Runtime 结果取得供应商用量回执。
    usage = result.usage
    # 输入和输出 Token 都有值时才算用量完整。
    known = usage.input_tokens is not None and usage.output_tokens is not None
    # 先登记用量完整性，费用初始设为未知。
    self.set(usage_complete=known, cost_state="unknown")
    # 为 Langfuse 的原生用量字段组织数据。
    detail = {
        # 保留用量名称及它对应的数值。
        k: v
        # 从回执中分别取输入与输出 Token。
        for k, v in {"input": usage.input_tokens, "output": usage.output_tokens}.items()
        # 只保留已知值，零值也保留。
        if v is not None
    # 得到本次尝试的已知用量明细。
    }
    # 存在至少一项已知用量才写属性。
    if detail:
        # 把用量对象编码为 Langfuse 需要的 JSON 字符串。
        self.native("usage_details", json.dumps(detail))
    # 用量完整、结果已知且收到本地估价时才登记费用。
    if known and not result.upstream_outcome_unknown and self.cost is not None:
        # 写入受长度限制的原生模型名。
        self.native("model.name", result.requested_model[:256])
        # 将本地总估价写入原生费用字段。
        self.native("cost_details", json.dumps({"total": self.cost}))
        # 标记费用是完整估算，并登记估价来源。
        self.set(cost_state="complete_estimate", cost_source="litellm-1.106.6")
    # 记录 Attempt 自己的终态和安全错误码。
    self.complete(result.status, result.error.code if result.error else None)
    # 结束 Span，交给后台导出。
    self.end()
```

##### SDK Metrics、诊断日志与统一出口

状态接口读本机 SDK Meter 数据，再叠加出口自己的拒绝、失败计数。Python 日志只接收诊断事件。`GuardedExporter` 在后台批处理中检查 Span，随后把通过检查的批次交给 OTLP Exporter。

```python export.py · 本机 SDK Metrics
# 组装当前 Agent 进程的观测管道状态。
def status(self):
    # 将队列深度和 SDK 丢弃计数初始化为零。
    size = dropped = 0
    # 从本机 SDK 的内存 Reader 读取当前指标。
    metrics = self.reader.get_metrics_data()
    # 有指标数据时再遍历各层。
    if metrics:
        # 按资源遍历这次指标快照。
        for resource in metrics.resource_metrics:
            # 按埋点作用域取出指标。
            for scope in resource.scope_metrics:
                # 逐个识别与导出管道相关的指标名。
                for metric in scope.metrics:
                    # 找到 BSP 队列当前深度的指标。
                    if metric.name == "otel.sdk.processor.span.queue.size":
                        # 将深度的数据点合计到队列长度。
                        size += sum(
                            # 把每个深度数据点的数值转为整数。
                            int(getattr(point, "value", 0)) for point in metric.data.data_points
                        # 完成队列深度汇总。
                        )
                    # 找到 BSP 已处理 Span 的计数指标。
                    if metric.name == "otel.sdk.processor.span.processed":
                        # 从处理计数中单独汇总丢弃项。
                        dropped += sum(
                            # 把匹配的数据点数值转为整数。
                            int(getattr(point, "value", 0))
                            # 遍历该指标下不同结果标签的数据点。
                            for point in metric.data.data_points
                            # 读取数据点的处理错误类型。
                            if (point.attributes or {}).get("error.type")
                            # 只统计队列满和关闭后无法接受的两类丢弃。
                            in {"queue_full", "already_shutdown"}
                        # 完成 SDK 丢弃计数的合计。
                        )
    # 持有导出器的锁，读取同一份出口状态。
    with self.exporter.lock:
        # 返回平台管理页所需的状态字段。
        return {
            # 报告当前进程待导出的队列深度。
            "queue_size": size,
            # 给出配置的 BSP 队列上限。
            "queue_capacity": 512,
            # 将 SDK 丢弃与出口校验拒绝合并。
            "dropped": dropped + self.exporter.rejected,
            # 报告后台导出失败的累计次数。
            "export_failures": self.exporter.failures,
            # 报告最近一次导出状态。
            "last_export": self.exporter.last,
        # 完成当前进程状态快照。
        }
```

```python privacy.py · 诊断日志
# 为观测管道的安全诊断日志定义格式。
class DiagnosticFormatter(logging.Formatter):
    # 将一条 Python 日志记录转换成一行 JSON。
    def format(self, record):
        # 用固定字段构造输出。
        return json.dumps(
            # 开始组装日志记录对象。
            {
                # 标记这是观测管道的诊断事件。
                "event": "observability",
                # 保留 INFO、WARNING 等日志级别。
                "level": record.levelname,
                # 用实例 ID 定位产生诊断的进程。
                "instance_id": getattr(record, "instance_id", ""),
                # 缺少安全原因时使用固定的兜底类别。
                "reason": getattr(record, "safe_reason", "dependency_failure"),
                # 追加调用方已过滤的计数值。
                **getattr(record, "safe_counts", {}),
            # 完成单条诊断记录的数据对象。
            },
            # 使用紧凑分隔符，便于容器按行采集。
            separators=(",", ":"),
        # 返回这一条已序列化的日志。
        )


# 记录一次受控的观测诊断事件。
def diagnostic(instance_id, reason, counts=None):
    # 取得 Compass 观测模块的专用 logger。
    logger = logging.getLogger("compass.observability")
    # 仅在首次使用时安装日志 handler。
    if not logger.handlers:
        # 创建输出到标准错误流的 handler。
        handler = logging.StreamHandler()
        # 指定结构化 JSON 格式。
        handler.setFormatter(DiagnosticFormatter())
        # 把 handler 注册到专用 logger。
        logger.addHandler(handler)
        # 阻止同一记录再传给父 logger 重复输出。
        logger.propagate = False
        # 允许正常关机事件以 INFO 级别输出。
        logger.setLevel(logging.INFO)
    # 构造可安全输出的计数字典。
    safe_counts = {
        # 保留符合条件的键和值。
        key: value
        # 逐项检查调用方附带的计数。
        for key, value in (counts or {}).items()
        # 只接受已登记的观测诊断计数名。
        if key in {"queue_size", "dropped", "export_failures", "instrumentation_errors"}
        # 只收整数，排除布尔值及其他类型。
        and type(value) is int
        # 计数必须为非负数。
        and value >= 0
    # 得到用于诊断的安全计数。
    }
    # 通过专用 logger 发出诊断事件。
    logger.log(
        # 关机使用 INFO，其他诊断使用 WARNING。
        logging.INFO if reason == "shutdown" else logging.WARNING,
        # 用固定消息标识观测模块。
        "observability",
        # 把实例、固定原因和安全计数交给格式化器。
        extra={"instance_id": instance_id, "safe_reason": reason, "safe_counts": safe_counts},
    # 提交本条日志记录。
    )
```

```python export.py · GuardedExporter.export
# 在后台接收 BSP 交来的一个 Span 批次。
def export(self, spans):
    # 准备收集通过出口检查的 Span。
    valid = []
    # 把登记的业务字段映射为 Langfuse metadata 键，并合入允许的原生键。
    allowed = {"langfuse.observation.metadata." + key for key in FIELDS} | {
        # 允许区分普通 Span 和 Generation。
        "langfuse.observation.type",
        # 允许 Langfuse 展示本次观测的级别。
        "langfuse.observation.level",
        # 允许用部署环境区分不同数据。
        "langfuse.environment",
        # 允许设置 Trace 的固定展示名。
        "langfuse.trace.name",
        # 允许用业务调用编号关联请求记录。
        "langfuse.trace.metadata.call_id",
        # 允许写入受控的状态说明或错误码。
        "langfuse.observation.status_message",
        # 允许在符合估价条件时登记原生模型名。
        "langfuse.observation.model.name",
        # 允许发送已知 Token 用量。
        "langfuse.observation.usage_details",
        # 允许发送本地估价。
        "langfuse.observation.cost_details",
        # 允许发送流式首个可见片段的时间。
        "langfuse.observation.completion_start_time",
    # 完成允许字段的集合。
    }
    # 对这一批 Span 逐条核验。
    for span in spans:
        # 取得 Span 属性，缺失时用空字典。
        attrs = span.attributes or {}
        # 把模型输入输出作为一类单独检查。
        body = {"langfuse.observation.input", "langfuse.observation.output"}
        # 检查这个 Span 中实际存在的正文属性是否全部合格。
        content_valid = all(
            # 正文采集须经过已配置的内容策略。
            self.content is not None
            # 正文须通过结构、长度和清洗检查。
            and self.content.accepts(attrs[key])
            # 仅接受 Generation 上的输入输出。
            and attrs.get("langfuse.observation.type") == "generation"
            # 逐一检查已存在的输入和输出键。
            for key in body & attrs.keys()
        # 得到本条 Span 的正文检查结果。
        )
        # 以下任一条件命中时拒绝导出这条 Span。
        if (
            # 先判断 Span 的埋点来源。
            (
                # 拒绝缺少埋点作用域的记录。
                span.instrumentation_scope is None
                # 只接收 Compass 手动观测模块生成的 Span。
                or span.instrumentation_scope.name != "compass.observability"
            # 结束作用域检查。
            )
            # 拒绝包含未登记属性名的 Span。
            or not set(attrs).issubset(allowed | body)
            # 拒绝正文检查未通过的 Span。
            or not content_valid
            # 正文之外的属性必须符合标量类型和长度规则。
            or any(scalar(value) is None for key, value in attrs.items() if key not in body)
            # 拒绝包含原始 Span Event 的记录。
            or bool(span.events)
        # 按检查结果选择丢弃或放行。
        ):
            # 持锁更新共享的拒绝计数。
            with self.lock:
                # 本次拒绝计入本机诊断。
                self.rejected += 1
        # 通过所有检查后组装用于导出的安全副本。
        else:
            # Tracestate may contain vendor text. It is used for trusted internal
            # propagation, while the telemetry sink receives only IDs and flags.
            # 把清理后的 Span 放入待发送批次。
            valid.append(
                # 构造 SDK 导出器可读取的 Span 对象。
                ReadableSpan(
                    # 沿用原 Span 操作名。
                    name=span.name,
                    # 保留 Trace 和 Span 标识，清除内部 tracestate。
                    context=export_context(span.context),
                    # 保留父级关系，同样清除父上下文的 tracestate。
                    parent=export_context(span.parent),
                    # 保留服务、实例等资源信息。
                    resource=span.resource,
                    # 带上已核验的属性。
                    attributes=span.attributes,
                    # 沿用已通过检查的事件集合，此处为空。
                    events=span.events,
                    # 保留关联字段，当前 Compass Span 不添加 Link。
                    links=span.links,
                    # 沿用 SDK 的操作类型。
                    kind=span.kind,
                    # 保留 OTel 状态。
                    status=span.status,
                    # 沿用开始时间。
                    start_time=span.start_time,
                    # 沿用结束时间，便于接收端计算耗时。
                    end_time=span.end_time,
                    # 保留已经核验的埋点作用域。
                    instrumentation_scope=span.instrumentation_scope,
                # 完成安全 Span 副本的构造。
                )
            # 将这一条加入待发送批次。
            )
    # 如果整个批次没有可发送的 Span，提前结束。
    if not valid:
        # 这批已完成本地处理，无需发网络请求。
        return SpanExportResult.SUCCESS
    # 隔离底层导出器异常。
    try:
        # 把核验过的批次交给 OTLP 导出器发送。
        result = self.inner.export(valid)
    # 底层导出过程抛异常时进入失败分支。
    except Exception:
        # 统一转换为 SDK 可识别的导出失败。
        result = SpanExportResult.FAILURE
    # 持锁更新后台导出状态与计数。
    with self.lock:
        # 保存最近一次导出的成功或失败状态。
        self.last = "success" if result == SpanExportResult.SUCCESS else "failure"
        # 仅失败时累加导出失败数。
        if result != SpanExportResult.SUCCESS:
            # 为该次失败增加一个计数。
            self.failures += 1
            # 失败日志之间至少间隔 30 秒。
            if monotonic() - self.last_warning >= 30:
                # 更新最近一次打印告警的单调时钟时间。
                self.last_warning = monotonic()
                # 记录带实例 ID 的安全导出失败日志。
                diagnostic(self.instance_id, "export_failed")
    # 将导出结果返回给 OTel SDK。
    return result
```

### 3. 观测字段与统计口径

| 字段                                         | 写入位置                                     | 查询口径                                                                                        |
| -------------------------------------------- | -------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| `langfuse.observation.metadata.*`            | `fields()` 显式映射业务键                    | 在 Langfuse 可按阶段、状态、模型、Provider、版本、实例和调用编号过滤                            |
| `langfuse.observation.input` / `output`      | 已采样的 Attempt，且开启正文采集             | 本地默认启用正文采集。每侧默认 16 KiB，过长保留预览与截断标记，失败或取消的可用片段标为 partial |
| `langfuse.observation.usage_details`         | Generation                                   | 已知的输入、输出 Token 分别记录。reasoning Token 作为 metadata，属于输出用量子集                |
| `langfuse.observation.cost_details`          | Generation，已知完整用量、结果已知且存在估价 | USD 本地估价。未知通过 `cost_state=unknown` 区分，汇总保留未知样本数                            |
| `first_visible_ms` / `completion_start_time` | 流式第一个可见正文或工具片段                 | 前者由单调时钟计算，后者用于 Langfuse 识别首片段时点。纯思考与心跳不计首片段                    |

**两模型对比。** Langfuse Metrics v2 以环境、时间窗、`provider_id`、当前 `model` 和 `stage=inference` 为过滤条件。逻辑调用数、成功率和耗时来自 `compass.logical`。尝试次数、Token 和费用来自 `compass.attempt`。每个模型 7 个固定查询，两个模型共 14 个，并发 4，总预算 8 秒。状态页显示当前实例，模型比较聚合同一项目的多实例样本。

**本轮查链。** `X-Compass-Trace-Id` 和 `X-Compass-Trace-Sampled` 经 BFF 校验透传，Web 在读取 SSE 正文前保存编号。打开 Langfuse 后用观测编号找到 Trace，选择 `compass.attempt` 查看 Input / Output。业务 `call_id` 可作为 metadata 过滤条件。

```typescript model-agent-client.ts
function readTraceHeaders(response: Response): Record<string, string> {
  const id = response.headers.get("X-Compass-Trace-Id");
  const sampled = response.headers.get("X-Compass-Trace-Sampled");
  if (!id || !/^[0-9a-f]{32}$/.test(id) || !/^(0|1)$/.test(sampled ?? "")) return {};
  return { "X-Compass-Trace-Id": id, "X-Compass-Trace-Sampled": sampled! };
}
```

### 4. 文件变更与内容清单

范围为第 14 课观测功能的运行、界面、契约、配置、测试和材料。标记以进入第 14 课前的代码为基准，路径相对 Compass 根目录。

#### 4.1 Agent

```text Agent 文件树
apps/agent/
├── src/
│   └── compass_agent/
│       ├── llm/
│       │   ├── contracts.py         [调整] CallSession 携带请求级观测句柄
│       │   ├── executor.py          [调整] wait / attempt / backoff、首片段及取消收尾
│       │   ├── litellm_chat.py      [调整] 请求级 LiteLLM 回调与安全估价
│       │   ├── runtime.py           [调整] 传递句柄，在 Adapter 前投影输入
│       │   └── sdk.py               [调整] SDK 加载后安装依赖日志过滤
│       ├── models/
│       │   └── service.py           [调整] Logical Call 贯穿准备到收尾，新增 finalize Span
│       ├── observability/
│       │   ├── __init__.py          [新增] 观测模块包入口
│       │   ├── content.py           [新增] 模型输入输出投影、凭据过滤和截断
│       │   ├── export.py            [新增] BSP、OTLP HTTP、导出检查和本机 SDK Metrics
│       │   ├── litellm_receipt.py   [新增] 请求级成本回执与本地估价条件
│       │   ├── observer.py          [新增] 根与子句柄、上下文、I/O、用量、状态与生命周期
│       │   ├── privacy.py           [新增] 元数据白名单与安全诊断日志
│       │   ├── README.md            [新增] 模块边界及验证入口
│       │   └── summary.py           [新增] 固定 Langfuse 查询与聚合口径
│       ├── routing/
│       │   └── service.py           [调整] 标明分类与推理 stage，记录路由快照
│       ├── main.py                  [调整] lifespan 创建 Observer，模型任务结束后关闭
│       ├── model_api.py             [调整] 已授权请求根、结束与关联头、状态和比较接口
│       ├── schemas.py               [调整] 状态与两模型对比 DTO
│       └── settings.py              [调整] 开关、采样、实例、正文策略、项目 Key 与服务地址
├── tests/
│   ├── observability_acceptance.py  [新增] Langfuse、真实 PostgreSQL 与多进程验收
│   ├── provider_fixture.py          [调整] 受控重试与模型响应
│   └── test_observability.py        [新增] 关联、采样、安全字段、统计和有界导出
├── pyproject.toml                   [调整] 锁定 OTel API、SDK 和 HTTP 导出依赖
└── README.md                        [调整] Agent 观测入口与配置说明
```

#### 4.2 Web

```text Web 文件树
apps/web/
├── src/
│   ├── app/
│   │   └── globals.css                  [调整] 观测面板、复制行和窄屏样式
│   ├── client/
│   │   └── request-scope.ts             [调整] 在响应正文前读取响应头
│   ├── components/
│   │   └── analysis-composer.tsx        [调整] 分析 Chat 关联本轮 Trace
│   ├── contracts/
│   │   └── trace-context.ts             [新增] Trace ID 与 sampled 格式校验
│   ├── features/
│   │   └── models/
│   │       ├── call-trace.tsx           [新增] 显示和复制本轮调用及观测编号
│   │       ├── observability-panel.tsx  [新增] 管理员状态、Langfuse 跳转和固定对比
│   │       ├── output.tsx               [调整] 模型测试结果显示关联信息
│   │       ├── pages.tsx                [调整] 平台模型管理挂载调用观测小节
│   │       ├── README.md                [调整] 功能边界与入口
│   │       └── use-model-call.ts        [调整] 保存本轮 Trace，在取消和失败后保留
│   ├── generated/
│   │   ├── api.ts                       [生成] Web 使用的 Agent 类型
│   │   └── model-contracts.schema.json  [生成] BFF 的运行时校验副本
│   └── server/
│       ├── http/
│       │   └── model-handler.ts         [调整] 平台权限、固定查询转发和错误关联
│       ├── agent-api.ts                 [调整] 暴露 BFF 使用的观测接口和头处理入口
│       └── model-agent-client.ts        [调整] Agent 响应头、JSON/SSE 契约及错误归一
├── tests/
│   ├── domain/
│   │   └── model-bff.test.ts            [调整] 平台权限、安全头及超时关联
│   └── e2e/
│       └── observability.spec.ts        [新增] Chat、平台对比、权限、取消与窄屏
└── README.md                            [调整] 管理面板、地址与权限说明
```

#### 4.3 共享契约、部署与工程配置

```text 共享交付文件树
compass/
├── contracts/
│   ├── model-contracts.schema.json  [生成] Agent 观测 DTO 的运行时校验契约
│   ├── openapi.json                 [生成] Agent 路由及观测状态、比较模型
│   └── README.md                    [调整] 契约生成来源与用途
├── deploy/
│   ├── compose/
│   │   ├── compose.yaml             [调整] Agent / Web 可选私有配置、Agent 关闭宽限
│   │   └── observability.yaml       [新增] 固定镜像的六服务和持久卷
│   ├── observability/
│   │   └── README.md                [新增] Langfuse 部署、数据路径、分布式关联与备份
│   └── README.md                    [调整] 本地观测栈入口
├── scripts/
│   ├── observability.mjs            [新增] 私有配置初始化和六服务启停
│   ├── observability.test.mjs       [新增] 初始化、文件权限与受管命令测试
│   └── README.md                    [调整] 观测运维命令说明
├── .env.example                     [调整] 宿主观测配置模板
├── manifest.yml                     [调整] 第 14 课交付入口
├── package.json                     [调整] pnpm observability 入口
├── README.md                        [调整] Feature 990 能力与启动入口
├── turbo.json                       [调整] dev 透传观测配置变量
└── uv.lock                          [调整] OTel 依赖锁定
```

#### 4.4 需求与课程材料

```text 第 14 课材料文件树
mai-specs/
├── 990-lesson-14-model-observability/
│   ├── design/
│   │   ├── document/
│   │   │   ├── edition.json            [新增] 渲染配置与代码引用
│   │   │   └── guide.md                [新增] 阅读版章节、图与代码摘录
│   │   ├── CODE_DESIGN.md              [新增] 代码设计附录
│   │   ├── README.md                   [新增] 阅读版维护入口
│   │   ├── TECH_DESIGN.html            [生成] 离线阅读版
│   │   └── TECH_DESIGN.md              [新增] 技术设计真源
│   ├── review/
│   │   ├── code_review.md              [新增] 代码自检
│   │   └── design_review.md            [新增] 设计评审
│   ├── spec/
│   │   └── PRD.md                      [新增] 产品需求与验收条件
│   ├── BRIEF.md                        [新增] 需求入口、范围与关键决定
│   ├── context/                        [新增] 四页 PPT 与开发上下文
│   └── IMPLEMENTATION.md               [新增] 实施与验收记录
└── ROADMAP.md                          [调整] 第 14 课实施登记
```

### 5. OTel 与 Langfuse 配置及初始化

#### 5.1 三份本地配置

| 配置来源                       | 读取方           | 关键内容                                                              |
| ------------------------------ | ---------------- | --------------------------------------------------------------------- |
| `work/observability/stack.env` | Langfuse Compose | 初始化组织、项目、管理员、项目 Key 与独立存储凭据                     |
| `work/observability/agent.env` | Compose Agent    | 观测开关、环境、正文开关、服务内地址、项目 Key。宿主开发对应根 `.env` |
| `work/observability/web.env`   | Compose Web      | 固定项目 URL。宿主开发对应根 `.env` 的 Web 服务端变量                 |

本地启动用 `pnpm observability init` 创建三份私有配置，`pnpm observability up` 启动栈。下面是版本库中的宿主配置模板和初始化片段。模板中 Key 为空。

```bash .env.example · 宿主开发模板
# 第14课观测默认关闭。先 pnpm observability init/up；私有 Key 见 work/observability/agent.env。
# Docker Agent 使用自动生成的 agent.env；宿主开发使用下面的 loopback 地址。
COMPASS_OBSERVABILITY_ENABLED=false
COMPASS_OBSERVABILITY_SAMPLE_RATIO=1
COMPASS_OBSERVABILITY_ENVIRONMENT=local
# 正文采集：未配置时 local 默认开启，其他环境默认关闭。显式 false 可关闭。
# COMPASS_OBSERVABILITY_CAPTURE_CONTENT=false
# 每个 Attempt 的输入、输出分别最多 16 KiB；超长内容保留脱敏预览与截断标记。
COMPASS_OBSERVABILITY_CONTENT_MAX_BYTES=16384
# 留空时每次进程启动生成唯一实例ID；多副本配置时每个值应不同。
COMPASS_OBSERVABILITY_INSTANCE_ID=
COMPASS_LANGFUSE_BASE_URL=http://127.0.0.1:8104
COMPASS_LANGFUSE_PUBLIC_KEY=
COMPASS_LANGFUSE_SECRET_KEY=
# Web 服务端的公开项目页面入口；不含项目 Key。
COMPASS_LANGFUSE_PROJECT_URL=
```

```javascript scripts/observability.mjs · 项目引导与私有配置
export function initialize(root) {
  const directory = path.join(root, "work/observability");
  const targets = ["stack.env", "agent.env", "web.env"];
  if (targets.some((name) => existsSync(path.join(directory, name))))
    throw new Error("Private observability configuration already exists; preserving it.");
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  const secret = () => randomBytes(32).toString("hex");
  const values = Object.fromEntries(
    [
      "LF_POSTGRES_PASSWORD",
      "LF_CLICKHOUSE_PASSWORD",
      "LF_REDIS_PASSWORD",
      "LF_MINIO_PASSWORD",
      "LF_NEXTAUTH_SECRET",
      "LF_SALT",
      "LF_ENCRYPTION_KEY",
      "LF_ADMIN_PASSWORD",
    ].map((key) => [key, secret()]),
  );
  Object.assign(values, {
    LF_MINIO_USER: `lf${randomBytes(10).toString("hex")}`,
    LF_ORG_ID: randomUUID(),
    LF_PROJECT_ID: randomUUID(),
    COMPASS_LANGFUSE_PUBLIC_KEY: `pk-lf-${randomUUID()}`,
    COMPASS_LANGFUSE_SECRET_KEY: `sk-lf-${secret()}`,
  });
  const serialize = (data) =>
    Object.entries(data)
      .map(([key, value]) => `${key}=${value}`)
      .join("\n") + "\n";
  writeFileSync(path.join(directory, "stack.env"), serialize(values), { mode: 0o600, flag: "wx" });
  writeFileSync(
    path.join(directory, "agent.env"),
    serialize({
      COMPASS_OBSERVABILITY_ENABLED: "true",
      COMPASS_OBSERVABILITY_ENVIRONMENT: "local",
      COMPASS_OBSERVABILITY_CAPTURE_CONTENT: "true",
      COMPASS_OBSERVABILITY_CONTENT_MAX_BYTES: "16384",
      COMPASS_LANGFUSE_BASE_URL: "http://langfuse-web:3000",
      COMPASS_LANGFUSE_PUBLIC_KEY: values.COMPASS_LANGFUSE_PUBLIC_KEY,
      COMPASS_LANGFUSE_SECRET_KEY: values.COMPASS_LANGFUSE_SECRET_KEY,
    }),
    { mode: 0o600, flag: "wx" },
  );
  writeFileSync(
    path.join(directory, "web.env"),
    serialize({
      COMPASS_LANGFUSE_PROJECT_URL: `http://127.0.0.1:8104/project/${values.LF_PROJECT_ID}`,
    }),
    { mode: 0o600, flag: "wx" },
  );
  return directory;
}
```

```yaml deploy/compose/observability.yaml · Langfuse Web 与首次引导
services:
  langfuse-web:
    profiles: [observability]
    image: langfuse/langfuse:4.75.0@sha256:23378ae8cdf1d92b647d68b81c0d0cea3632b43e9fbcbe9b765420af9c9c8662
    environment: &langfuse-env
      HOSTNAME: 0.0.0.0
      DATABASE_URL: postgresql://langfuse:${LF_POSTGRES_PASSWORD:?Run observability init}@langfuse-postgres:5432/langfuse
      NEXTAUTH_URL: http://127.0.0.1:8104
      NEXTAUTH_SECRET: ${LF_NEXTAUTH_SECRET:?}
      SALT: ${LF_SALT:?}
      ENCRYPTION_KEY: ${LF_ENCRYPTION_KEY:?}
      TELEMETRY_ENABLED: "false"
      LANGFUSE_MIGRATION_V4_ALLOW_PREVIEW_OPT_IN: "true"
      LANGFUSE_MIGRATION_V4_WRITE_MODE: events_only
      CLICKHOUSE_MIGRATION_URL: clickhouse://langfuse-clickhouse:9000
      CLICKHOUSE_URL: http://langfuse-clickhouse:8123
      CLICKHOUSE_USER: langfuse
      CLICKHOUSE_PASSWORD: ${LF_CLICKHOUSE_PASSWORD:?}
      CLICKHOUSE_CLUSTER_ENABLED: "false"
      REDIS_HOST: langfuse-redis
      REDIS_PORT: "6379"
      REDIS_AUTH: ${LF_REDIS_PASSWORD:?}
      LANGFUSE_S3_EVENT_UPLOAD_BUCKET: langfuse
      LANGFUSE_S3_EVENT_UPLOAD_REGION: us-east-1
      LANGFUSE_S3_EVENT_UPLOAD_ACCESS_KEY_ID: ${LF_MINIO_USER:?}
      LANGFUSE_S3_EVENT_UPLOAD_SECRET_ACCESS_KEY: ${LF_MINIO_PASSWORD:?}
      LANGFUSE_S3_EVENT_UPLOAD_ENDPOINT: http://langfuse-minio:9000
      LANGFUSE_S3_EVENT_UPLOAD_FORCE_PATH_STYLE: "true"
      LANGFUSE_S3_MEDIA_UPLOAD_BUCKET: langfuse
      LANGFUSE_S3_MEDIA_UPLOAD_REGION: us-east-1
      LANGFUSE_S3_MEDIA_UPLOAD_ACCESS_KEY_ID: ${LF_MINIO_USER:?}
      LANGFUSE_S3_MEDIA_UPLOAD_SECRET_ACCESS_KEY: ${LF_MINIO_PASSWORD:?}
      LANGFUSE_S3_MEDIA_UPLOAD_ENDPOINT: http://langfuse-minio:9000
      LANGFUSE_S3_MEDIA_UPLOAD_FORCE_PATH_STYLE: "true"
      LANGFUSE_INIT_ORG_ID: ${LF_ORG_ID:?}
      LANGFUSE_INIT_ORG_NAME: Compass Local
      LANGFUSE_INIT_PROJECT_ID: ${LF_PROJECT_ID:?}
      LANGFUSE_INIT_PROJECT_NAME: compass-local
      LANGFUSE_INIT_PROJECT_PUBLIC_KEY: ${COMPASS_LANGFUSE_PUBLIC_KEY:?}
      LANGFUSE_INIT_PROJECT_SECRET_KEY: ${COMPASS_LANGFUSE_SECRET_KEY:?}
      LANGFUSE_INIT_USER_EMAIL: local.admin@compass.invalid
      LANGFUSE_INIT_USER_NAME: Compass Local
      LANGFUSE_INIT_USER_PASSWORD: ${LF_ADMIN_PASSWORD:?}
    ports: ["127.0.0.1:8104:3000"]
```

#### 5.2 Agent 生命周期与 SDK 装配

`lifespan()` 创建每进程一个 `Observer`。`Observer.__init__()` 装配独立 TracerProvider、实例 Resource、采样器和 Pipeline。`Pipeline.__init__()` 创建本地 MetricReader、OTLP HTTP 导出器和 BSP。退出时先收束模型任务，再关观测。

```python main.py · Agent 生命周期
@asynccontextmanager
async def lifespan(app):
    settings = get_settings()
    app.state.execution_gate = ExecutionGate(
        settings.compass_model_max_concurrency, settings.compass_model_max_inflight
    )
    app.state.model_tasks = ExecutionTasks()
    app.state.observation = Observer(settings)
    app.state.showcase_running = False
    try:
        yield
    finally:
        await app.state.model_tasks.close()
        await asyncio.to_thread(app.state.observation.shutdown)
```

```python observer.py · OTel TracerProvider 与采样
def __init__(self, settings, *, exporter=None):
    self.instance_id = settings.compass_observability_instance_id or str(uuid4())
    self.environment = settings.compass_observability_environment
    self.ratio = settings.compass_observability_sample_ratio
    self.enabled = settings.compass_observability_enabled
    self.content = ContentPolicy(
        settings.capture_observability_content,
        settings.compass_observability_content_max_bytes,
    )
    self.configured = bool(
        settings.compass_langfuse_base_url
        and settings.compass_langfuse_public_key
        and settings.compass_langfuse_secret_key
    )
    self.provider = self.tracer = self.pipeline = None
    self.closed = False
    self.instrumentation_errors = 0
    install_dependency_filters()
    if self.enabled and (self.configured or exporter is not None):
        from compass_agent.observability.export import Pipeline

        os.environ["OTEL_PYTHON_SDK_INTERNAL_METRICS_ENABLED"] = "true"
        self.provider = TracerProvider(
            resource=Resource(
                {
                    "service.name": "compass-agent",
                    "service.namespace": "compass",
                    "service.instance.id": self.instance_id,
                    "service.version": "0.1.0",
                    "deployment.environment.name": self.environment,
                }
            ),
            sampler=ParentBased(TraceIdRatioBased(self.ratio)),
            span_limits=SpanLimits(
                max_attributes=64,
                max_events=16,
                max_links=0,
                max_attribute_length=self.content.max_bytes if self.content.enabled else 256,
            ),
            shutdown_on_exit=False,
        )
        self.pipeline = Pipeline(
            settings, self.provider, exporter=exporter, instance_id=self.instance_id
        )
        self.tracer = self.provider.get_tracer("compass.observability")
```

```python export.py · OTel Pipeline 与 Langfuse OTLP
def __init__(self, settings, provider, *, exporter=None, instance_id=""):
    self.reader = InMemoryMetricReader()
    self.meters = MeterProvider(metric_readers=[self.reader])
    if exporter is None:
        auth = base64.b64encode(
            f"{settings.compass_langfuse_public_key}:{settings.compass_langfuse_secret_key.get_secret_value()}".encode()
        ).decode()
        exporter = OTLPSpanExporter(
            endpoint=settings.compass_langfuse_base_url.rstrip("/")
            + "/api/public/otel/v1/traces",
            headers={"Authorization": "Basic " + auth, "x-langfuse-ingestion-version": "4"},
            timeout=2,
        )
    from compass_agent.observability.content import ContentPolicy

    self.exporter = GuardedExporter(
        exporter,
        instance_id,
        ContentPolicy(
            settings.capture_observability_content,
            settings.compass_observability_content_max_bytes,
        ),
    )
    self.processor = BatchSpanProcessor(
        self.exporter,
        max_queue_size=512,
        max_export_batch_size=64,
        schedule_delay_millis=1000,
        meter_provider=self.meters,
    )
    provider.add_span_processor(self.processor)
```

### 6. 核心 Observation 模块解析

| 源码                          | 关注点                                                               |
| ----------------------------- | -------------------------------------------------------------------- |
| `observer.py` · `Observer`    | 配置判定、实例身份、根 Span、状态与关闭                              |
| `observer.py` · `Observation` | 当前 Span 的显式所有者。建立父子关系，累积属性、状态与估价，统一结束 |
| `privacy.py` / `content.py`   | 元数据白名单、正文选取与限长、凭据过滤、依赖日志清洗                 |
| `litellm_receipt.py`          | 请求级用量/估价回执，流式完成后补充已知估价                          |
| `export.py`                   | 有界批处理、出口校验、传输和本机 SDK 诊断                            |
| `summary.py`                  | 固定观察数据筛选，限制聚合并发、响应体和总等待                       |

#### 6.1 创建句柄与关联上下文

`Observation` 使用显式父句柄建立子 Span。业务 metadata 从父句柄复制，子级按自己的 `call_id`、阶段和模型补充。内部传播调用 `carrier()`，响应关联调用 `headers()`。

```python observer.py · W3C 上下文提取
def remote_context(carrier):
    """Call only after service authentication; ignore baggage and malformed carriers."""
    safe = {}
    for name in ("traceparent", "tracestate"):
        value = carrier.get(name)
        if isinstance(value, str) and len(value) <= 512:
            safe[name] = value
    return PROPAGATOR.extract(safe, context=Context())
```

```python observer.py · 显式父子关系与字段写入
def __init__(self, owner, name, attributes=None, parent=None, context=None):
    self.owner, self.name, self.parent = owner, name, parent
    self.metadata = {**(parent.metadata if parent else {}), **(attributes or {})}
    self.root = parent.root if parent else self
    self.started_ns = monotonic_ns()
    self.ended = self.authoritative = False
    self.first_ns = None
    self.status = None
    self.lock = Lock()
    self.cost = None
    self._content_secrets = ()
    self.span = None
    if owner.tracer:
        try:
            self.span = owner.tracer.start_span(
                name,
                context=trace.set_span_in_context(parent.span)
                if parent and parent.span
                else context or Context(),
                attributes={
                    "langfuse.observation.type": "span",
                    "langfuse.environment": owner.environment,
                    "langfuse.trace.name": "compass.request",
                    **fields({"instance_id": owner.instance_id, **self.metadata}),
                },
            )
        except Exception:
            owner.instrumentation_errors += 1

def child(self, name, **attributes):
    return Observation(self.owner, name, attributes, parent=self)

def set(self, **attributes):
    self.metadata.update(attributes)
    if self.span and not self.ended:
        try:
            self.span.set_attributes(fields(attributes))
        except Exception:
            self.owner.instrumentation_errors += 1

def native(self, key, value):
    if self.span and not self.ended:
        try:
            self.span.set_attribute("langfuse.observation." + key, value)
        except Exception:
            self.owner.instrumentation_errors += 1
```

```python observer.py · 响应关联与内部传播
def headers(self):
    if not self.span:
        return {}
    ctx = self.span.get_span_context()
    return {
        "X-Compass-Trace-Id": f"{ctx.trace_id:032x}",
        "X-Compass-Trace-Sampled": "1" if ctx.trace_flags.sampled else "0",
    }

def carrier(self):
    result = {}
    if self.span:
        PROPAGATOR.inject(result, context=trace.set_span_in_context(self.span))
    return result
```

#### 6.2 正文字段、估价与晚到回调

`ContentPolicy` 控制正文写入范围。只投影可见消息、工具字段及类型化结果。正文开关未设置时，仅 `local` 默认开启。其他环境可通过部署配置显式覆盖。输入在 Runtime 准备完成后抓取，流式输出以组装后的可用结果为准。配置的供应商 Key 用于替换正文里的精确匹配，私有思考、续接 Token、原始异常和 HTTP 头留在遥测字段之外。

```python observer.py · 正文采集与安全边界
def capture_input(self, request):
    if not self.owner.content.enabled or not self.span or not self.span.is_recording():
        return
    try:
        self._content_secrets = (request.access.api_key.get_secret_value(),)
        encoded, truncated = self.owner.content.encode(
            input_snapshot(request.input), self._content_secrets
        )
        self.native("input", encoded)
        self.set(content_input_truncated=truncated)
    except Exception:
        self.owner.instrumentation_errors += 1

def capture_output(self, result):
    if not self.owner.content.enabled or not self.span or not self.span.is_recording():
        return
    try:
        value = output_snapshot(getattr(result, "output", None))
        if value is not None:
            encoded, truncated = self.owner.content.encode(value, self._content_secrets)
            self.native("output", encoded)
            self.set(
                content_output_truncated=truncated,
                content_output_partial=result.status != "completed",
            )
    except Exception:
        self.owner.instrumentation_errors += 1
```

```python litellm_receipt.py · 请求级成本回执与本地估价
def callbacks(observation):
    async def success(kwargs, response_obj, start_time, end_time):
        try:
            if complete_usage(response_obj):
                observation.accept_cost(kwargs.get("response_cost"))
        except Exception:
            return

    async def failure(kwargs, response_obj, start_time, end_time):
        return

    return {"success_callback": [success], "failure_callback": [failure]}


def estimate(observation, sdk, response, model):
    if observation.cost is not None:
        return
    try:
        if complete_usage(response):
            observation.accept_cost(sdk.completion_cost(completion_response=response, model=model))
    except Exception:
        # Missing prices and unsupported usage categories remain unknown.
        return
```

#### 6.3 一处结束，收尾失败优先

`complete()` 保存终态。业务写库失败会将权威失败提升到请求 Span，避免覆盖成普通取消。`end()` 在锁内做幂等检查、映射状态和结束 Span，已结束句柄忽略迟到的估价回执。

```python observer.py · 权威终态
def complete(self, status, code=None, *, authoritative=False):
    with self.lock:
        if self.ended or self.authoritative:
            return
        self.status = (status, error_code(code))
        self.authoritative = authoritative
    if code == "record_write_failed" and self.root is not self:
        self.root.complete("failed", code, authoritative=True)
```

```python observer.py · 幂等结束
def end(self):
    with self.lock:
        if self.ended:
            return
        self._content_secrets = ()
        status, code = self.status or ("completed", None)
        self.set(status=status, error_code=code)
        if self.span:
            try:
                level = (
                    "DEFAULT"
                    if status == "completed"
                    else "WARNING"
                    if status == "canceled"
                    else "ERROR"
                )
                self.native("level", level)
                if code:
                    self.native("status_message", code)
                if status in {"failed", "incomplete"}:
                    self.span.set_status(Status(StatusCode.ERROR))
                self.span.end()
            except Exception:
                self.owner.instrumentation_errors += 1
        self.ended = True
```
