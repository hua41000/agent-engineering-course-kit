# 第 14 课学习资料

《企业级Agent工程架构实战营》｜正式课第 14 课

## 阅读顺序

1. [PRD](PRD.md)列出功能、业务规则与 18 项验收条件。
2. [Markdown 技术方案](TECH_DESIGN.md)说明设计、部署、接口、统计口径，并附架构图和源码导读。Mermaid 图需支持 Mermaid 的阅读器。
3. 双击 [离线 HTML 技术方案](TECH_DESIGN.html)，可使用目录、搜索、代码复制、图表缩放与 SVG 导出。

## 实战范围

Compass Feature 990 覆盖 OTel 调用链、跨实例关联、安全导出、Langfuse 查询和平台固定模型对比。模型预算扣减、正式计费、完整 Replay、强审计、生产高可用和 Worker 业务消费属于后续范围。真实供应商验收与生产负载数据仍待验证。

启用观测后，`local` 环境在正文开关未配置时默认采集，初始化命令也会为本地 Agent 写入开启配置。其他环境默认关闭，可由部署显式覆盖。课堂哨兵与白名单验收显式设置 `COMPASS_OBSERVABILITY_CAPTURE_CONTENT=false`。开启时，仅在已采样的 Attempt 写入受限的输入和输出，包含选取的消息、结构化输入、工具字段及可见结果。默认每侧 16 KiB，超长内容保留预览和截断标记。程序过滤已知凭据和私有字段，仍可能保留业务正文。带真实业务数据的环境使用关闭配置。

本包为 Compass 工程资料的分发副本。维护源位于 Compass 的 `mai-specs/990-lesson-14-model-observability/`。
